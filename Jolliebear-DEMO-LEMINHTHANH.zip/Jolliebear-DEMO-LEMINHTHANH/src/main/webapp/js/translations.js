/* Jolliebear Internationalization (i18n) Translations Dictionary */

const translations = {
    vi: {
        // TOP UTILITY & NAVBAR
        welcome_msg: "Chào mừng bạn đến với Jolliebear!",
        nav_home: "TRANG CHỦ",
        nav_about: "VỀ JOLLIEBEAR",
        nav_menu: "THỰC ĐƠN",
        nav_promotions: "KHUYẾN MÃI",
        nav_services: "DỊCH VỤ",
        nav_news: "TIN TỨC",
        nav_stores: "CỬA HÀNG",
        nav_contact: "LIÊN HỆ",
        nav_jobs: "TUYỂN DỤNG",
        btn_register: "ĐĂNG KÝ",
        btn_login: "ĐĂNG NHẬP",
        btn_logout: "ĐĂNG XUẤT",
        btn_admin_portal: "QUẢN TRỊ",
        user_welcome: "Chào, ",

        // HERO SLIDER
        hero_badge: "BÁN CHẠY NHẤT",
        hero_title_1: "Gà Giòn Vui Vẻ",
        hero_desc_1: "Từng miếng gà chiên vàng ươm, giòn rụm bên ngoài và đậm đà mọng nước bên trong. Thưởng thức ngay cùng sốt cay thượng hạng!",
        hero_btn_order: "ĐẶT MÓN NGAY",
        hero_btn_menu: "XEM THỰC ĐƠN",

        // ORDER SECTION
        delivery_mode: "GIAO HÀNG TẬN NƠI",
        pickup_mode: "ĐẶT ĐẾN LẤY",
        address_placeholder: "Nhập địa chỉ giao hàng của bạn...",

        // FEATURED MENU SECTION
        featured_title: "ĂN GÌ HÔM NAY",
        featured_desc: "Thực đơn Jolliebear đa dạng và phong phú, có rất nhiều sự lựa chọn cho bạn, gia đình và bạn bè.",
        view_menu_link: "Xem thực đơn",

        // MENU SECTION (DYNAMIC)
        menu_section_title: "THỰC ĐƠN JOLLIEBEAR",
        menu_section_subtitle: "Khám phá danh sách các món ăn ngon khó cưỡng được chế biến từ nguyên liệu tươi ngon nhất.",
        search_food_placeholder: "Tìm kiếm món ăn yêu thích...",
        cat_all: "Tất cả",
        cat_gagion: "Gà Giòn",
        cat_myy: "Mỳ Ý",
        cat_burger: "Burger",
        cat_combo: "Combo Tiết Kiệm",
        cat_nuoc: "Nước & Tráng Miệng",
        btn_add_to_cart: "Đặt Món Ngay",
        price_currency: "đ",
        no_food_found: "Không tìm thấy món ăn phù hợp.",

        // NEWS SECTION
        news_section_title: "TIN TỨC & KHUYẾN MÃI",
        news_section_subtitle: "Cập nhật các chương trình ưu đãi mới nhất và sự kiện hấp dẫn từ Jolliebear.",
        btn_read_more: "Xem chi tiết",

        // STORES SECTION
        stores_section_title: "HỆ THỐNG CỬA HÀNG",
        stores_section_subtitle: "Tìm kiếm cửa hàng Jolliebear gần bạn nhất để thưởng thức trực tiếp hoặc đặt giao hàng.",
        search_store_placeholder: "Nhập địa chỉ hoặc quận/huyện...",

        // JOBS SECTION
        jobs_section_title: "TUYỂN DỤNG JOLLIEBEAR",
        jobs_section_subtitle: "Gia nhập đại gia đình Jolliebear với môi trường làm việc năng động và cơ hội thăng tiến.",
        search_job_placeholder: "Tìm vị trí tuyển dụng...",
        deadline_label: "Hạn nộp: ",
        btn_apply_now: "Ứng tuyển ngay",

        // CONTACT SECTION
        contact_section_title: "LIÊN HỆ VỚI CHÚNG TÔI",
        contact_section_subtitle: "Chúng tôi luôn lắng nghe ý kiến đóng góp của bạn để nâng cao chất lượng dịch vụ.",
        form_name: "Họ và tên *",
        form_email: "Địa chỉ Email *",
        form_phone: "Số điện thoại",
        form_subject: "Tiêu đề *",
        form_message: "Nội dung tin nhắn *",
        btn_send_contact: "Gửi Ý Kiến Liên Hệ",

        // FOOTER
        footer_brand_desc: "Thương hiệu gà rán vui vẻ số 1 Việt Nam. Mang lại nụ cười và bữa ăn ngon cho mọi gia đình.",
        footer_quick_links: "Liên Kết Nhanh",
        footer_contact_info: "Thông Tin Liên Hệ",
        footer_address: "120 Lê Lai, Phường Bến Thành, Quận 1, TP. HCM",
        footer_copyright: "© 2026 Jolliebear Vietnam. Tất cả quyền được bảo lưu.",

        // DASHBOARD (ADMIN & STAFF)
        db_title: "Hệ thống quản trị",
        db_overview: "Tổng quan",
        db_menu_mgmt: "Quản lý thực đơn",
        db_news_mgmt: "Quản lý tin tức",
        db_stores_mgmt: "Hệ thống cửa hàng",
        db_jobs_mgmt: "Tin tuyển dụng",
        db_contacts_mgmt: "Ý kiến liên hệ",
        db_users_mgmt: "Tài khoản thành viên",
        db_stat_members: "Thành viên",
        db_stat_menu: "Món ăn thực đơn",
        db_stat_news: "Bài viết tin tức",
        db_stat_stores: "Cửa hàng",
        db_stat_jobs: "Tin tuyển dụng",
        db_welcome_title: "Chào mừng trở lại!",
        db_welcome_desc: "Đây là hệ thống quản trị nội bộ của Jolliebear. Bạn có thể cập nhật thực đơn, tin tức, cửa hàng và tin tuyển dụng hiển thị trực tiếp lên website chính.",
        db_view_main_site: "Xem website chính",
        db_btn_add_new: "Thêm mới",
        db_tbl_img: "Ảnh",
        db_tbl_name: "Tên món",
        db_tbl_category: "Danh mục",
        db_tbl_price: "Giá bán",
        db_tbl_actions: "Thao tác",
        db_tbl_status: "Trạng thái"
    },
    en: {
        // TOP UTILITY & NAVBAR
        welcome_msg: "Welcome to Jolliebear Official Site!",
        nav_home: "HOME",
        nav_about: "ABOUT US",
        nav_menu: "MENU",
        nav_promotions: "PROMOTIONS",
        nav_services: "SERVICES",
        nav_news: "NEWS",
        nav_stores: "LOCATIONS",
        nav_contact: "CONTACT",
        nav_jobs: "CAREERS",
        btn_register: "REGISTER",
        btn_login: "LOG IN",
        btn_logout: "LOG OUT",
        btn_admin_portal: "DASHBOARD",
        user_welcome: "Welcome, ",

        // HERO SLIDER
        hero_badge: "BEST SELLER",
        hero_title_1: "Crispy Chickenjoy",
        hero_desc_1: "Golden fried chicken, crunchy on the outside and juicy on the inside. Enjoy now with our signature spicy glaze!",
        hero_btn_order: "ORDER NOW",
        hero_btn_menu: "EXPLORE MENU",

        // ORDER SECTION
        delivery_mode: "DELIVERY",
        pickup_mode: "PICK UP",
        address_placeholder: "Enter your delivery address...",

        // FEATURED MENU SECTION
        featured_title: "WHAT TO EAT TODAY",
        featured_desc: "Explore Jolliebear's diverse menu with delicious choices for you, family and friends.",
        view_menu_link: "View menu",

        // MENU SECTION (DYNAMIC)
        menu_section_title: "JOLLIEBEAR MENU",
        menu_section_subtitle: "Discover irresistible dishes made from the freshest quality ingredients.",
        search_food_placeholder: "Search your favorite food...",
        cat_all: "All Items",
        cat_gagion: "Crispy Chicken",
        cat_myy: "Spaghetti",
        cat_burger: "Burgers",
        cat_combo: "Saver Combos",
        cat_nuoc: "Drinks & Desserts",
        btn_add_to_cart: "Order Now",
        price_currency: "VND",
        no_food_found: "No matching food items found.",

        // NEWS SECTION
        news_section_title: "NEWS & PROMOTIONS",
        news_section_subtitle: "Stay updated with the latest special offers and exciting events from Jolliebear.",
        btn_read_more: "Read details",

        // STORES SECTION
        stores_section_title: "STORE LOCATOR",
        stores_section_subtitle: "Find the nearest Jolliebear store to dine in or place a delivery order.",
        search_store_placeholder: "Enter address or district...",

        // JOBS SECTION
        jobs_section_title: "CAREER OPPORTUNITIES",
        jobs_section_subtitle: "Join the Jolliebear family with a dynamic working environment and growth potential.",
        search_job_placeholder: "Search job title...",
        deadline_label: "Deadline: ",
        btn_apply_now: "Apply Now",

        // CONTACT SECTION
        contact_section_title: "CONTACT US",
        contact_section_subtitle: "We value your feedback to continuously improve our service quality.",
        form_name: "Full Name *",
        form_email: "Email Address *",
        form_phone: "Phone Number",
        form_subject: "Subject *",
        form_message: "Message Content *",
        btn_send_contact: "Send Message",

        // FOOTER
        footer_brand_desc: "Vietnam's #1 Joyful Fried Chicken Brand. Bringing smiles and delicious meals to every family.",
        footer_quick_links: "Quick Links",
        footer_contact_info: "Contact Info",
        footer_address: "120 Le Lai St, Ben Thanh Ward, District 1, HCMC",
        footer_copyright: "© 2026 Jolliebear Vietnam. All rights reserved.",

        // DASHBOARD (ADMIN & STAFF)
        db_title: "Management System",
        db_overview: "Overview",
        db_menu_mgmt: "Menu Management",
        db_news_mgmt: "News Management",
        db_stores_mgmt: "Store Locations",
        db_jobs_mgmt: "Job Recruitment",
        db_contacts_mgmt: "Customer Feedback",
        db_users_mgmt: "User Accounts",
        db_stat_members: "Total Members",
        db_stat_menu: "Menu Items",
        db_stat_news: "News Articles",
        db_stat_stores: "Store Locations",
        db_stat_jobs: "Job Openings",
        db_welcome_title: "Welcome Back!",
        db_welcome_desc: "This is Jolliebear's internal management dashboard. You can update menu items, news, stores, and careers directly onto the main site.",
        db_view_main_site: "View Main Site",
        db_btn_add_new: "Add New",
        db_tbl_img: "Image",
        db_tbl_name: "Item Name",
        db_tbl_category: "Category",
        db_tbl_price: "Price",
        db_tbl_actions: "Actions",
        db_tbl_status: "Status"
    }
};

// Global language switcher helper
function applyTranslations(lang = 'vi') {
    const dict = translations[lang] || translations.vi;
    
    // Update elements with data-i18n attribute
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (dict[key]) {
            if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                if (el.hasAttribute('placeholder')) {
                    el.setAttribute('placeholder', dict[key]);
                }
            } else {
                el.textContent = dict[key];
            }
        }
    });

    // Update active language selector style
    document.querySelectorAll('#lang-vi, #lang-en').forEach(el => {
        el.classList.remove('active');
    });
    const activeBtn = document.getElementById(`lang-${lang}`);
    if (activeBtn) activeBtn.classList.add('active');

    // Save language choice to localStorage
    localStorage.setItem('jolliebear_lang', lang);
}
