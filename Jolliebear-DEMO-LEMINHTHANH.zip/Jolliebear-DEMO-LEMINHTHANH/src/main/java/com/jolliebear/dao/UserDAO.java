package com.jolliebear.dao;

import com.jolliebear.model.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    // Keep constructor with String parameter for compatibility with Servlet init methods
    public UserDAO(String contextPath) {
        // No longer need JSON file path, DBConnection handles SQL initialization
    }

    public UserDAO() {
    }

    public synchronized List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String sql = "SELECT name, phone, email, password, role FROM users";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                users.add(new User(
                    rs.getString("name"),
                    rs.getString("phone"),
                    rs.getString("email"),
                    rs.getString("password"),
                    rs.getString("role")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }

    public synchronized boolean saveUser(User user) {
        // Check duplicate
        String checkSql = "SELECT COUNT(*) FROM users WHERE email = ? OR phone = ?";
        String insertSql = "INSERT INTO users (name, phone, email, password, role) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection()) {
            // Check duplicates
            try (PreparedStatement psCheck = conn.prepareStatement(checkSql)) {
                psCheck.setString(1, user.getEmail());
                psCheck.setString(2, user.getPhone());
                try (ResultSet rs = psCheck.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        return false; // Duplicate email or phone
                    }
                }
            }
            
            // Insert
            try (PreparedStatement psInsert = conn.prepareStatement(insertSql)) {
                psInsert.setString(1, user.getName());
                psInsert.setString(2, user.getPhone());
                psInsert.setString(3, user.getEmail());
                psInsert.setString(4, user.getPassword());
                psInsert.setString(5, user.getRole() != null ? user.getRole() : "CUSTOMER");
                int rows = psInsert.executeUpdate();
                return rows > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public synchronized User findUser(String emailOrPhone, String password) {
        String sql = "SELECT name, phone, email, password, role FROM users WHERE (email = ? OR phone = ?) AND password = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, emailOrPhone.trim());
            ps.setString(2, emailOrPhone.trim());
            ps.setString(3, password);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new User(
                        rs.getString("name"),
                        rs.getString("phone"),
                        rs.getString("email"),
                        rs.getString("password"),
                        rs.getString("role")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public synchronized boolean updateUserRole(String email, String role) {
        String sql = "UPDATE users SET role = ? WHERE email = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, role);
            ps.setString(2, email);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public synchronized boolean deleteUser(String email) {
        String sql = "DELETE FROM users WHERE email = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public synchronized boolean updateUser(User user, String oldEmail) {
        String sql = "UPDATE users SET name = ?, phone = ?, email = ?, password = ?, role = ? WHERE email = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, user.getName());
            ps.setString(2, user.getPhone());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getPassword());
            ps.setString(5, user.getRole());
            ps.setString(6, oldEmail);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
