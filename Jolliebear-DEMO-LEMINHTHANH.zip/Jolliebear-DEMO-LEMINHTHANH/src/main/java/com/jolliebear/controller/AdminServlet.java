package com.jolliebear.controller;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.jolliebear.dao.DBConnection;
import com.jolliebear.dao.UserDAO;
import com.jolliebear.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

@WebServlet("/api/admin")
public class AdminServlet extends HttpServlet {
    private UserDAO userDAO;

    @Override
    public void init() throws ServletException {
        userDAO = new UserDAO();
    }

    private boolean isAdmin(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            return false;
        }
        User user = (User) session.getAttribute("user");
        return "ADMIN".equalsIgnoreCase(user.getRole());
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Gson gson = new Gson();
        JsonObject jsonResponse = new JsonObject();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            jsonResponse.addProperty("status", "error");
            jsonResponse.addProperty("message", "Vui lòng đăng nhập.");
            out.print(gson.toJson(jsonResponse));
            return;
        }

        User user = (User) session.getAttribute("user");
        String role = user.getRole();
        
        // Both STAFF and ADMIN can view stats, but only ADMIN can view users list
        String action = request.getParameter("action");
        if ("stats".equalsIgnoreCase(action)) {
            if (!"STAFF".equalsIgnoreCase(role) && !"ADMIN".equalsIgnoreCase(role)) {
                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                jsonResponse.addProperty("status", "error");
                jsonResponse.addProperty("message", "Bạn không có quyền truy cập thống kê.");
                out.print(gson.toJson(jsonResponse));
                return;
            }
            
            // Get stats
            try (Connection conn = DBConnection.getConnection();
                 Statement stmt = conn.createStatement()) {
                
                int usersCount = 0;
                int menuCount = 0;
                int newsCount = 0;
                int storesCount = 0;
                int jobsCount = 0;
                int unreadContacts = 0;

                try (ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM users")) {
                    if (rs.next()) usersCount = rs.getInt(1);
                }
                try (ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM menu_items")) {
                    if (rs.next()) menuCount = rs.getInt(1);
                }
                try (ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM news")) {
                    if (rs.next()) newsCount = rs.getInt(1);
                }
                try (ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM stores")) {
                    if (rs.next()) storesCount = rs.getInt(1);
                }
                try (ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM jobs")) {
                    if (rs.next()) jobsCount = rs.getInt(1);
                }
                try (ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM contacts WHERE is_read = 0")) {
                    if (rs.next()) unreadContacts = rs.getInt(1);
                }

                JsonObject stats = new JsonObject();
                stats.addProperty("users", usersCount);
                stats.addProperty("menu", menuCount);
                stats.addProperty("news", newsCount);
                stats.addProperty("stores", storesCount);
                stats.addProperty("jobs", jobsCount);
                stats.addProperty("unreadContacts", unreadContacts);

                jsonResponse.addProperty("status", "success");
                jsonResponse.add("stats", stats);
                out.print(gson.toJson(jsonResponse));
                
            } catch (SQLException e) {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                jsonResponse.addProperty("status", "error");
                jsonResponse.addProperty("message", "Lỗi CSDL: " + e.getMessage());
                out.print(gson.toJson(jsonResponse));
            }
        } else {
            // ADMIN only: list all users
            if (!"ADMIN".equalsIgnoreCase(role)) {
                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                jsonResponse.addProperty("status", "error");
                jsonResponse.addProperty("message", "Bạn không có quyền thực hiện hành động này.");
                out.print(gson.toJson(jsonResponse));
                return;
            }
            List<User> usersList = userDAO.getAllUsers();
            out.print(gson.toJson(usersList));
        }
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Gson gson = new Gson();
        JsonObject jsonResponse = new JsonObject();

        if (!isAdmin(request)) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            jsonResponse.addProperty("status", "error");
            jsonResponse.addProperty("message", "Yêu cầu quyền ADMIN.");
            out.print(gson.toJson(jsonResponse));
            return;
        }

        try {
            StringBuilder sb = new StringBuilder();
            String line;
            try (BufferedReader reader = request.getReader()) {
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }

            User user = gson.fromJson(sb.toString(), User.class);
            if (user == null || user.getEmail() == null || user.getPhone() == null 
                    || user.getPassword() == null || user.getName() == null) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                jsonResponse.addProperty("status", "error");
                jsonResponse.addProperty("message", "Dữ liệu không đầy đủ.");
                out.print(gson.toJson(jsonResponse));
                return;
            }

            boolean success = userDAO.saveUser(user);
            if (success) {
                jsonResponse.addProperty("status", "success");
                jsonResponse.addProperty("message", "Đã tạo tài khoản thành công!");
            } else {
                response.setStatus(HttpServletResponse.SC_CONFLICT);
                jsonResponse.addProperty("status", "error");
                jsonResponse.addProperty("message", "Email hoặc số điện thoại đã tồn tại.");
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.addProperty("status", "error");
            jsonResponse.addProperty("message", "Lỗi: " + e.getMessage());
        }
        out.print(gson.toJson(jsonResponse));
        out.flush();
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Gson gson = new Gson();
        JsonObject jsonResponse = new JsonObject();

        if (!isAdmin(request)) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            jsonResponse.addProperty("status", "error");
            jsonResponse.addProperty("message", "Yêu cầu quyền ADMIN.");
            out.print(gson.toJson(jsonResponse));
            return;
        }

        try {
            StringBuilder sb = new StringBuilder();
            String line;
            try (BufferedReader reader = request.getReader()) {
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }

            JsonObject dataObj = gson.fromJson(sb.toString(), JsonObject.class);
            if (dataObj == null || !dataObj.has("email") || !dataObj.has("role") 
                    || !dataObj.has("name") || !dataObj.has("phone")) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                jsonResponse.addProperty("status", "error");
                jsonResponse.addProperty("message", "Dữ liệu không hợp lệ.");
                out.print(gson.toJson(jsonResponse));
                return;
            }

            String oldEmail = dataObj.get("email").getAsString();
            String name = dataObj.get("name").getAsString();
            String phone = dataObj.get("phone").getAsString();
            String role = dataObj.get("role").getAsString();
            String password = dataObj.has("password") ? dataObj.get("password").getAsString() : "";
            
            // Build user object
            User user = new User(name, phone, oldEmail, password, role);
            if (dataObj.has("newEmail") && !dataObj.get("newEmail").getAsString().isEmpty()) {
                user.setEmail(dataObj.get("newEmail").getAsString());
            }

            boolean success = userDAO.updateUser(user, oldEmail);
            if (success) {
                jsonResponse.addProperty("status", "success");
                jsonResponse.addProperty("message", "Đã cập nhật tài khoản thành công!");
            } else {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                jsonResponse.addProperty("status", "error");
                jsonResponse.addProperty("message", "Không thể cập nhật tài khoản.");
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.addProperty("status", "error");
            jsonResponse.addProperty("message", "Lỗi: " + e.getMessage());
        }
        out.print(gson.toJson(jsonResponse));
        out.flush();
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Gson gson = new Gson();
        JsonObject jsonResponse = new JsonObject();

        if (!isAdmin(request)) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            jsonResponse.addProperty("status", "error");
            jsonResponse.addProperty("message", "Yêu cầu quyền ADMIN.");
            out.print(gson.toJson(jsonResponse));
            return;
        }

        String email = request.getParameter("email");
        if (email == null) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            jsonResponse.addProperty("status", "error");
            jsonResponse.addProperty("message", "Thiếu email tài khoản cần xóa.");
            out.print(gson.toJson(jsonResponse));
            return;
        }

        // Prevent admin from deleting themselves
        HttpSession session = request.getSession(false);
        User currentUser = (User) session.getAttribute("user");
        if (currentUser.getEmail().equalsIgnoreCase(email)) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            jsonResponse.addProperty("status", "error");
            jsonResponse.addProperty("message", "Bạn không thể tự xóa tài khoản của chính mình.");
            out.print(gson.toJson(jsonResponse));
            return;
        }

        boolean success = userDAO.deleteUser(email);
        if (success) {
            jsonResponse.addProperty("status", "success");
            jsonResponse.addProperty("message", "Đã xóa tài khoản thành công!");
        } else {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            jsonResponse.addProperty("status", "error");
            jsonResponse.addProperty("message", "Không thể xóa tài khoản.");
        }
        out.print(gson.toJson(jsonResponse));
        out.flush();
    }
}
