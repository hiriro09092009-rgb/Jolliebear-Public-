package com.jolliebear.filter;

import jakarta.servlet.*;

import java.io.IOException;

/**
 * Ép buộc UTF-8 cho MỌI request và response.
 *
 * Đây là filter QUAN TRỌNG NHẤT để tránh lỗi hiển thị dấu "?" thay cho ký tự
 * tiếng Việt có dấu: nếu không gọi setCharacterEncoding("UTF-8") TRƯỚC KHI đọc
 * bất kỳ tham số request nào (request.getParameter(...)), container sẽ dùng
 * encoding mặc định (thường là ISO-8859-1) để giải mã dữ liệu form POST
 * (VD: form đăng ký, đăng nhập, checkout), làm hỏng vĩnh viễn các ký tự có dấu
 * trước khi dữ liệu đó được lưu vào SQL Server.
 *
 * Khai báo qua web.xml (không dùng @WebFilter) để đảm bảo thứ tự chạy TRƯỚC LocaleFilter.
 */
public class EncodingFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        chain.doFilter(request, response);
    }
}
