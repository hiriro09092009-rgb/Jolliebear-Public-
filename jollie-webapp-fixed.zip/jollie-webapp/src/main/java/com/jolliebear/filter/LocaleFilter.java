package com.jolliebear.filter;

import jakarta.servlet.*;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * Đọc cookie "lang" (vi/en) và đưa vào:
 *  - request attribute "lang"          -> dùng trong JSP: ${lang == 'en' ? ... : ...}
 *  - HttpServletRequest.getLocale-like -> không cần, EL đơn giản hơn cho JSP thuần.
 * Mặc định là "vi" nếu chưa từng chọn (cookie chưa tồn tại).
 * LanguageServlet (/lang?code=vi|en) là nơi duy nhất GHI cookie này.
 */
public class LocaleFilter implements Filter {

    public static final String COOKIE_NAME = "lang";
    public static final String DEFAULT_LANG = "vi";

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;

        String lang = DEFAULT_LANG;
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie c : cookies) {
                if (COOKIE_NAME.equals(c.getName()) && ("vi".equals(c.getValue()) || "en".equals(c.getValue()))) {
                    lang = c.getValue();
                    break;
                }
            }
        }

        request.setAttribute("lang", lang);
        chain.doFilter(req, res);
    }
}
