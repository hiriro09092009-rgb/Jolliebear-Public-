package com.jolliebear.util;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;

/**
 * Băm mật khẩu bằng PBKDF2WithHmacSHA256 (chuẩn NIST, có sẵn trong JDK -
 * không cần thêm thư viện ngoài như BCrypt). Mỗi user có 1 salt ngẫu nhiên riêng
 * nên 2 user dùng cùng mật khẩu vẫn ra hash khác nhau, chống rainbow table.
 */
public final class PasswordUtil {

    private static final int ITERATIONS = 120_000;
    private static final int KEY_LENGTH = 256;
    private static final SecureRandom RANDOM = new SecureRandom();

    private PasswordUtil() {
    }

    public static String generateSalt() {
        byte[] salt = new byte[16];
        RANDOM.nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    public static String hash(String rawPassword, String base64Salt) {
        try {
            byte[] salt = Base64.getDecoder().decode(base64Salt);
            PBEKeySpec spec = new PBEKeySpec(rawPassword.toCharArray(), salt, ITERATIONS, KEY_LENGTH);
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            byte[] hash = factory.generateSecret(spec).getEncoded();
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new IllegalStateException("Không thể băm mật khẩu", e);
        }
    }

    public static boolean matches(String rawPassword, String base64Salt, String expectedHash) {
        String actualHash = hash(rawPassword, base64Salt);
        return java.security.MessageDigest.isEqual(
                actualHash.getBytes(), expectedHash.getBytes());
    }
}
