package com.jolliebear.util;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

/**
 * Quản lý duy nhất 1 EntityManagerFactory cho toàn bộ ứng dụng.
 * Tên persistence-unit ("jolliePU") phải khớp với file
 * src/main/resources/META-INF/persistence.xml
 */
public class JPAUtil {

    private static final EntityManagerFactory EMF;

    static {
        try {
            EMF = Persistence.createEntityManagerFactory("jolliePU");
        } catch (Throwable ex) {
            // In lỗi rõ ràng ra console Tomcat để dễ debug (thường do sai user/pass/host SQL Server)
            System.err.println("!!! LỖI KHỞI TẠO JPA/HIBERNATE - KIỂM TRA LẠI persistence.xml VÀ KẾT NỐI SQL SERVER !!!");
            ex.printStackTrace();
            throw new ExceptionInInitializerError(ex);
        }
    }

    private JPAUtil() {
    }

    public static EntityManager getEntityManager() {
        return EMF.createEntityManager();
    }

    public static void shutdown() {
        if (EMF.isOpen()) {
            EMF.close();
        }
    }
}
