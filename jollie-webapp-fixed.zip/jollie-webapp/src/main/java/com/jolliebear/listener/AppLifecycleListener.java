package com.jolliebear.listener;

import com.jolliebear.util.JPAUtil;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

/**
 * Đóng EntityManagerFactory khi ứng dụng dừng (undeploy / Tomcat shutdown)
 * để tránh rò rỉ kết nối tới SQL Server.
 */
@WebListener
public class AppLifecycleListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        // Không cần làm gì - JPAUtil khởi tạo EMF lười (lazy) khi có request đầu tiên.
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        JPAUtil.shutdown();
    }
}
