package com.jolliebear.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Model dữ liệu cho 1 Dịch Vụ.
 * Map trực tiếp sang bảng "services" trong SQL Server qua JPA/Hibernate.
 * Cột tiếng Việt khai báo tường minh columnDefinition = "NVARCHAR(...)" để tạo
 * đúng kiểu NVARCHAR (tránh lỗi dấu "?" / lỗi "conversion from varchar to NCHAR").
 */
@Entity
@Table(name = "services")
public class ServiceItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String iconClass;

    @Column(columnDefinition = "NVARCHAR(300)")
    private String title;
    @Column(columnDefinition = "NVARCHAR(300)")
    private String titleEn;

    @Column(columnDefinition = "NVARCHAR(1000)")
    private String description;
    @Column(columnDefinition = "NVARCHAR(1000)")
    private String descriptionEn;

    @Column(columnDefinition = "NVARCHAR(100)")
    private String linkText;
    @Column(columnDefinition = "NVARCHAR(100)")
    private String linkTextEn;

    private String link;

    public ServiceItem() {
    }

    public ServiceItem(int id, String iconClass, String title, String titleEn, String description,
                        String descriptionEn, String linkText, String linkTextEn, String link) {
        this.id = id;
        this.iconClass = iconClass;
        this.title = title;
        this.titleEn = titleEn;
        this.description = description;
        this.descriptionEn = descriptionEn;
        this.linkText = linkText;
        this.linkTextEn = linkTextEn;
        this.link = link;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getIconClass() { return iconClass; }
    public void setIconClass(String iconClass) { this.iconClass = iconClass; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getTitleEn() { return titleEn; }
    public void setTitleEn(String titleEn) { this.titleEn = titleEn; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getDescriptionEn() { return descriptionEn; }
    public void setDescriptionEn(String descriptionEn) { this.descriptionEn = descriptionEn; }

    public String getLinkText() { return linkText; }
    public void setLinkText(String linkText) { this.linkText = linkText; }
    public String getLinkTextEn() { return linkTextEn; }
    public void setLinkTextEn(String linkTextEn) { this.linkTextEn = linkTextEn; }

    public String getLink() { return link; }
    public void setLink(String link) { this.link = link; }

    public String getDisplayTitle(String lang) {
        return ("en".equals(lang) && titleEn != null && !titleEn.isBlank()) ? titleEn : title;
    }
    public String getDisplayDescription(String lang) {
        return ("en".equals(lang) && descriptionEn != null && !descriptionEn.isBlank()) ? descriptionEn : description;
    }
    public String getDisplayLinkText(String lang) {
        return ("en".equals(lang) && linkTextEn != null && !linkTextEn.isBlank()) ? linkTextEn : linkText;
    }
}
