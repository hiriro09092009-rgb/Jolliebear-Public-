package com.jolliebear.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Model dữ liệu cho 1 chương trình Khuyến Mãi.
 * Map trực tiếp sang bảng "promotions" trong SQL Server qua JPA/Hibernate.
 * Các cột tiếng Việt khai báo tường minh columnDefinition = "NVARCHAR(...)" để
 * Hibernate CHẮC CHẮN tạo đúng kiểu NVARCHAR (xem giải thích chi tiết trong
 * MenuCategory.java) - tránh lỗi hiển thị dấu "?" / lỗi "conversion from varchar to NCHAR".
 */
@Entity
@Table(name = "promotions")
public class Promotion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(columnDefinition = "NVARCHAR(50)")
    private String badgeText;      // Nhãn góc thẻ: "-50%", "MUA 1 TẶNG 1"... (có dấu nên cần NVARCHAR)

    @Column(columnDefinition = "NVARCHAR(100)")
    private String label;          // Nhãn nhỏ phía trên tiêu đề
    @Column(columnDefinition = "NVARCHAR(100)")
    private String labelEn;

    @Column(columnDefinition = "NVARCHAR(300)")
    private String title;          // Tiêu đề chính
    @Column(columnDefinition = "NVARCHAR(300)")
    private String titleEn;

    @Column(columnDefinition = "NVARCHAR(1000)")
    private String description;    // Mô tả ngắn
    @Column(columnDefinition = "NVARCHAR(1000)")
    private String descriptionEn;

    // Giá hiển thị có chứa ký tự "đ" (Việt hóa), cũng cần NVARCHAR chứ không phải VARCHAR
    @Column(columnDefinition = "NVARCHAR(50)")
    private String priceNew;       // Giá sau khuyến mãi (hiển thị, VD "59.000đ")
    @Column(columnDefinition = "NVARCHAR(50)")
    private String priceOld;       // Giá gốc (có thể null nếu không áp dụng)
    private String iconClass;      // Class icon Font Awesome
    private String iconBgClass;    // Class CSS nền icon

    @Column(columnDefinition = "NVARCHAR(100)")
    private String buttonText;
    @Column(columnDefinition = "NVARCHAR(100)")
    private String buttonTextEn;

    private String buttonLink;

    public Promotion() {
    }

    public Promotion(int id, String badgeText, String label, String labelEn, String title, String titleEn,
                      String description, String descriptionEn, String priceNew, String priceOld,
                      String iconClass, String iconBgClass, String buttonText, String buttonTextEn,
                      String buttonLink) {
        this.id = id;
        this.badgeText = badgeText;
        this.label = label;
        this.labelEn = labelEn;
        this.title = title;
        this.titleEn = titleEn;
        this.description = description;
        this.descriptionEn = descriptionEn;
        this.priceNew = priceNew;
        this.priceOld = priceOld;
        this.iconClass = iconClass;
        this.iconBgClass = iconBgClass;
        this.buttonText = buttonText;
        this.buttonTextEn = buttonTextEn;
        this.buttonLink = buttonLink;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getBadgeText() { return badgeText; }
    public void setBadgeText(String badgeText) { this.badgeText = badgeText; }

    public String getLabel() { return label; }
    public void setLabel(String label) { this.label = label; }
    public String getLabelEn() { return labelEn; }
    public void setLabelEn(String labelEn) { this.labelEn = labelEn; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getTitleEn() { return titleEn; }
    public void setTitleEn(String titleEn) { this.titleEn = titleEn; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getDescriptionEn() { return descriptionEn; }
    public void setDescriptionEn(String descriptionEn) { this.descriptionEn = descriptionEn; }

    public String getPriceNew() { return priceNew; }
    public void setPriceNew(String priceNew) { this.priceNew = priceNew; }

    public String getPriceOld() { return priceOld; }
    public void setPriceOld(String priceOld) { this.priceOld = priceOld; }

    public String getIconClass() { return iconClass; }
    public void setIconClass(String iconClass) { this.iconClass = iconClass; }

    public String getIconBgClass() { return iconBgClass; }
    public void setIconBgClass(String iconBgClass) { this.iconBgClass = iconBgClass; }

    public String getButtonText() { return buttonText; }
    public void setButtonText(String buttonText) { this.buttonText = buttonText; }
    public String getButtonTextEn() { return buttonTextEn; }
    public void setButtonTextEn(String buttonTextEn) { this.buttonTextEn = buttonTextEn; }

    public String getButtonLink() { return buttonLink; }
    public void setButtonLink(String buttonLink) { this.buttonLink = buttonLink; }

    public String getDisplayLabel(String lang) {
        return ("en".equals(lang) && labelEn != null && !labelEn.isBlank()) ? labelEn : label;
    }
    public String getDisplayTitle(String lang) {
        return ("en".equals(lang) && titleEn != null && !titleEn.isBlank()) ? titleEn : title;
    }
    public String getDisplayDescription(String lang) {
        return ("en".equals(lang) && descriptionEn != null && !descriptionEn.isBlank()) ? descriptionEn : description;
    }
    public String getDisplayButtonText(String lang) {
        return ("en".equals(lang) && buttonTextEn != null && !buttonTextEn.isBlank()) ? buttonTextEn : buttonText;
    }
}
