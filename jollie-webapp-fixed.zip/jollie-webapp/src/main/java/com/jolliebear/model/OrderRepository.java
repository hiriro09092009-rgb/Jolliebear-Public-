package com.jolliebear.model;

import com.jolliebear.util.JPAUtil;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.time.LocalDateTime;
import java.util.List;

public class OrderRepository {

    public Order save(Order order) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            EntityTransaction tx = em.getTransaction();
            tx.begin();
            if (order.getCreatedAt() == null) {
                order.setCreatedAt(LocalDateTime.now());
            }
            if (order.getOrderCode() == null) {
                order.setOrderCode(generateOrderCode());
            }
            // Gắn lại user quản lý bởi EntityManager hiện tại để tránh lỗi "detached entity"
            User managedUser = em.find(User.class, order.getUser().getId());
            order.setUser(managedUser);
            em.persist(order);
            tx.commit();
            return order;
        } finally {
            em.close();
        }
    }

    public List<Order> findByUser(int userId) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            // JOIN FETCH items để orders.jsp có thể lặp qua o.items sau khi
            // EntityManager đã đóng, tránh LazyInitializationException.
            return em.createQuery(
                    "SELECT DISTINCT o FROM Order o LEFT JOIN FETCH o.items " +
                    "WHERE o.user.id = :uid ORDER BY o.createdAt DESC", Order.class)
                    .setParameter("uid", userId)
                    .getResultList();
        } finally {
            em.close();
        }
    }

    public Order findByIdAndUser(int orderId, int userId) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            return em.createQuery(
                    "SELECT DISTINCT o FROM Order o LEFT JOIN FETCH o.items " +
                    "WHERE o.id = :id AND o.user.id = :uid", Order.class)
                    .setParameter("id", orderId)
                    .setParameter("uid", userId)
                    .getResultStream().findFirst().orElse(null);
        } finally {
            em.close();
        }
    }

    private String generateOrderCode() {
        return "JB" + System.currentTimeMillis();
    }
}
