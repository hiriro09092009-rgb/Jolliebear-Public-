package com.jolliebear.model;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * 1 món ăn cụ thể trong 1 danh mục (VD: "Gà Giòn Vui Vẻ" trong danh mục "Gà Giòn").
 * Mỗi món có thể có nhiều nhóm tùy chọn (OptionGroup) - giống Grab/GrabFood:
 * VD "Chọn size" (bắt buộc, chọn 1), "Độ cay" (bắt buộc, chọn 1),
 * "Món thêm" (không bắt buộc, chọn nhiều).
 */
@Entity
@Table(name = "menu_items")
public class MenuItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private MenuCategory category;

    @Column(columnDefinition = "NVARCHAR(300) NOT NULL")
    private String name;
    @Column(columnDefinition = "NVARCHAR(300)")
    private String nameEn;

    @Column(columnDefinition = "NVARCHAR(1000)")
    private String description;
    @Column(columnDefinition = "NVARCHAR(1000)")
    private String descriptionEn;

    @Column(nullable = false, precision = 12, scale = 0)
    private BigDecimal basePrice;

    private String iconClass;
    private boolean available = true;
    private boolean bestSeller = false;

    @OneToMany(mappedBy = "menuItem", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<OptionGroup> optionGroups = new ArrayList<>();

    public MenuItem() {
    }

    public MenuItem(MenuCategory category, String name, String nameEn, String description,
                     String descriptionEn, BigDecimal basePrice, String iconClass, boolean bestSeller) {
        this.category = category;
        this.name = name;
        this.nameEn = nameEn;
        this.description = description;
        this.descriptionEn = descriptionEn;
        this.basePrice = basePrice;
        this.iconClass = iconClass;
        this.bestSeller = bestSeller;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public MenuCategory getCategory() { return category; }
    public void setCategory(MenuCategory category) { this.category = category; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getNameEn() { return nameEn; }
    public void setNameEn(String nameEn) { this.nameEn = nameEn; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getDescriptionEn() { return descriptionEn; }
    public void setDescriptionEn(String descriptionEn) { this.descriptionEn = descriptionEn; }

    public BigDecimal getBasePrice() { return basePrice; }
    public void setBasePrice(BigDecimal basePrice) { this.basePrice = basePrice; }

    public String getIconClass() { return iconClass; }
    public void setIconClass(String iconClass) { this.iconClass = iconClass; }

    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    public boolean isBestSeller() { return bestSeller; }
    public void setBestSeller(boolean bestSeller) { this.bestSeller = bestSeller; }

    public List<OptionGroup> getOptionGroups() { return optionGroups; }
    public void setOptionGroups(List<OptionGroup> optionGroups) { this.optionGroups = optionGroups; }

    public void addOptionGroup(OptionGroup g) {
        g.setMenuItem(this);
        optionGroups.add(g);
    }

    public String getDisplayName(String lang) {
        return ("en".equals(lang) && nameEn != null && !nameEn.isBlank()) ? nameEn : name;
    }
    public String getDisplayDescription(String lang) {
        return ("en".equals(lang) && descriptionEn != null && !descriptionEn.isBlank()) ? descriptionEn : description;
    }
}
