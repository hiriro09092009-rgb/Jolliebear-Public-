package com.jolliebear.model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

/**
 * 1 nhóm tùy chọn của món ăn, VD: "Chọn size", "Độ cay", "Món thêm".
 * required=true + multiSelect=false  -> hiển thị dạng radio button, bắt buộc chọn 1 (giống Grab).
 * required=false + multiSelect=true  -> hiển thị dạng checkbox, chọn 0..nhiều (topping thêm).
 */
@Entity
@Table(name = "option_groups")
public class OptionGroup {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "menu_item_id")
    private MenuItem menuItem;

    @Column(columnDefinition = "NVARCHAR(200) NOT NULL")
    private String name;
    @Column(columnDefinition = "NVARCHAR(200)")
    private String nameEn;

    private boolean required = false;
    private boolean multiSelect = false;
    private int displayOrder = 0;

    @OneToMany(mappedBy = "optionGroup", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<OptionChoice> choices = new ArrayList<>();

    public OptionGroup() {
    }

    public OptionGroup(String name, String nameEn, boolean required, boolean multiSelect, int displayOrder) {
        this.name = name;
        this.nameEn = nameEn;
        this.required = required;
        this.multiSelect = multiSelect;
        this.displayOrder = displayOrder;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public MenuItem getMenuItem() { return menuItem; }
    public void setMenuItem(MenuItem menuItem) { this.menuItem = menuItem; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getNameEn() { return nameEn; }
    public void setNameEn(String nameEn) { this.nameEn = nameEn; }

    public boolean isRequired() { return required; }
    public void setRequired(boolean required) { this.required = required; }

    public boolean isMultiSelect() { return multiSelect; }
    public void setMultiSelect(boolean multiSelect) { this.multiSelect = multiSelect; }

    public int getDisplayOrder() { return displayOrder; }
    public void setDisplayOrder(int displayOrder) { this.displayOrder = displayOrder; }

    public List<OptionChoice> getChoices() { return choices; }
    public void setChoices(List<OptionChoice> choices) { this.choices = choices; }

    public void addChoice(OptionChoice c) {
        c.setOptionGroup(this);
        choices.add(c);
    }

    public String getDisplayName(String lang) {
        return ("en".equals(lang) && nameEn != null && !nameEn.isBlank()) ? nameEn : name;
    }
}
