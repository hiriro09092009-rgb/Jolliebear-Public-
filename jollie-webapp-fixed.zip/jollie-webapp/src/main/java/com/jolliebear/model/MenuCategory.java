package com.jolliebear.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Model dữ liệu cho 1 Danh Mục Món Ăn ("Ăn Gì Hôm Nay").
 * Được map sang bảng "menu_categories" trong SQL Server qua JPA/Hibernate.
 *
 * QUAN TRỌNG VỀ ENCODING: các cột chứa tiếng Việt được khai báo tường minh
 * columnDefinition = "NVARCHAR(...)" để Hibernate CHẮC CHẮN tạo đúng kiểu NVARCHAR
 * (không dùng @Nationalized vì trên một số bản Hibernate 6 + driver mssql-jdbc,
 * annotation này không sinh đúng kiểu NVARCHAR khi tạo bảng, gây lỗi
 * "The conversion from varchar to NCHAR is unsupported" lúc đọc dữ liệu).
 * SQL Server chỉ lưu đúng ký tự Unicode (có dấu) trong các cột N-type;
 * nếu dùng VARCHAR thường, các ký tự có dấu sẽ bị SQL Server tự động đổi
 * thành dấu "?" khi lưu (không thể phục hồi lại được nữa).
 * Nếu bảng đã được tạo từ trước bằng VARCHAR, cần xoá bảng cũ (hoặc xoá cả
 * database JollieBearDB) rồi chạy lại ứng dụng để Hibernate tạo lại đúng kiểu NVARCHAR.
 */
@Entity
@Table(name = "menu_categories")
public class MenuCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String iconClass;   // Icon Font Awesome hiển thị trong ảnh mock, VD "fa-solid fa-drumstick-bite"
    private String bgClass;     // Class CSS nền ảnh: chicken-mock / spicy-mock / spaghetti-mock / dessert-mock

    @Column(columnDefinition = "NVARCHAR(300)")
    private String title;
    @Column(columnDefinition = "NVARCHAR(300)")
    private String titleEn;

    @Column(columnDefinition = "NVARCHAR(1000)")
    private String description;
    @Column(columnDefinition = "NVARCHAR(1000)")
    private String descriptionEn;

    private String link;

    public MenuCategory() {
    }

    public MenuCategory(int id, String iconClass, String bgClass, String title, String titleEn,
                         String description, String descriptionEn, String link) {
        this.id = id;
        this.iconClass = iconClass;
        this.bgClass = bgClass;
        this.title = title;
        this.titleEn = titleEn;
        this.description = description;
        this.descriptionEn = descriptionEn;
        this.link = link;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getIconClass() { return iconClass; }
    public void setIconClass(String iconClass) { this.iconClass = iconClass; }

    public String getBgClass() { return bgClass; }
    public void setBgClass(String bgClass) { this.bgClass = bgClass; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getTitleEn() { return titleEn; }
    public void setTitleEn(String titleEn) { this.titleEn = titleEn; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getDescriptionEn() { return descriptionEn; }
    public void setDescriptionEn(String descriptionEn) { this.descriptionEn = descriptionEn; }

    public String getLink() { return link; }
    public void setLink(String link) { this.link = link; }

    /** Dùng trong JSP: trả về tiêu đề theo ngôn ngữ hiện tại, tự rơi về tiếng Việt nếu chưa dịch. */
    public String getDisplayTitle(String lang) {
        if ("en".equals(lang) && titleEn != null && !titleEn.isBlank()) return titleEn;
        return title;
    }

    public String getDisplayDescription(String lang) {
        if ("en".equals(lang) && descriptionEn != null && !descriptionEn.isBlank()) return descriptionEn;
        return description;
    }
}
