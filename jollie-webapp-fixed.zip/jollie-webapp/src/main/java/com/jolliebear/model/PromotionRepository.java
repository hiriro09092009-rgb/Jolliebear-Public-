package com.jolliebear.model;

import com.jolliebear.util.JPAUtil;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.List;

/**
 * Nguồn dữ liệu Khuyến Mãi - đọc/ghi trực tiếp từ SQL Server qua JPA (Hibernate).
 * Nếu bảng "promotions" đang trống, tự động chèn dữ liệu mẫu để demo giao diện chạy được ngay.
 */
public class PromotionRepository {

    public List<Promotion> findAll() {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            List<Promotion> list = em.createQuery(
                    "SELECT p FROM Promotion p ORDER BY p.id", Promotion.class)
                    .getResultList();

            if (list.isEmpty()) {
                seedDefaultData(em);
                list = em.createQuery(
                        "SELECT p FROM Promotion p ORDER BY p.id", Promotion.class)
                        .getResultList();
            }
            return list;
        } finally {
            em.close();
        }
    }

    private void seedDefaultData(EntityManager em) {
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        em.persist(new Promotion(
                0, "-50%", "COMBO TIẾT KIỆM", "SAVER COMBO", "Combo Gà Giòn 2 Miếng", "2-Piece Crispy Chicken Combo",
                "Bao gồm 2 miếng gà giòn, 1 cơm, 1 nước ngọt size vừa.",
                "Includes 2 pieces of crispy chicken, 1 rice, 1 medium soft drink.",
                "59.000đ", "118.000đ",
                "fa-solid fa-bucket", "combo-icon",
                "Đặt ngay", "Order now", "menu"
        ));

        em.persist(new Promotion(
                0, "MUA 1 TẶNG 1", "ƯU ĐÃI THỨ 4", "WEDNESDAY DEAL", "Gà Sốt Cay Mua 1 Tặng 1", "Spicy Chicken Buy 1 Get 1",
                "Áp dụng cho đơn đặt qua ứng dụng, thứ 4 hàng tuần.",
                "Applies to app orders every Wednesday.",
                "39.000đ", "78.000đ",
                "fa-solid fa-pepper-hot", "spicy-icon",
                "Đặt ngay", "Order now", "menu"
        ));

        em.persist(new Promotion(
                0, "SINH VIÊN", "ƯU ĐÃI HỌC SINH SV", "STUDENT DEAL", "Giảm 20% Toàn Thực Đơn", "20% Off Whole Menu",
                "Chỉ cần xuất trình thẻ học sinh, sinh viên khi thanh toán.",
                "Just show your student ID at checkout.",
                "Giảm 20%", null,
                "fa-solid fa-graduation-cap", "student-icon",
                "Xem chi tiết", "View details", "menu"
        ));

        em.persist(new Promotion(
                0, "FREESHIP", "GIAO HÀNG TẬN NƠI", "FREE DELIVERY", "Miễn Phí Giao Hàng", "Free Shipping",
                "Cho đơn hàng từ 99.000đ trong bán kính 3km.",
                "For orders from 99,000đ within a 3km radius.",
                "0đ Ship", null,
                "fa-solid fa-motorcycle", "ship-icon",
                "Đặt ngay", "Order now", "menu"
        ));

        tx.commit();
    }
}
