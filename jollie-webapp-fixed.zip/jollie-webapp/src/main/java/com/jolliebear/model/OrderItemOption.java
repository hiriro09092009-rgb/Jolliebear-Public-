package com.jolliebear.model;

import jakarta.persistence.*;

import java.math.BigDecimal;

/** Snapshot 1 tùy chọn đã chọn cho 1 dòng món trong đơn hàng (VD: "Size: L (+10.000đ)"). */
@Entity
@Table(name = "order_item_options")
public class OrderItemOption {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_item_id")
    private OrderItem orderItem;

    @Column(columnDefinition = "NVARCHAR(200) NOT NULL")
    private String groupName;

    @Column(columnDefinition = "NVARCHAR(200) NOT NULL")
    private String choiceName;

    @Column(nullable = false, precision = 12, scale = 0)
    private BigDecimal extraPrice = BigDecimal.ZERO;

    public OrderItemOption() {
    }

    public OrderItemOption(String groupName, String choiceName, BigDecimal extraPrice) {
        this.groupName = groupName;
        this.choiceName = choiceName;
        this.extraPrice = extraPrice;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public OrderItem getOrderItem() { return orderItem; }
    public void setOrderItem(OrderItem orderItem) { this.orderItem = orderItem; }

    public String getGroupName() { return groupName; }
    public void setGroupName(String groupName) { this.groupName = groupName; }

    public String getChoiceName() { return choiceName; }
    public void setChoiceName(String choiceName) { this.choiceName = choiceName; }

    public BigDecimal getExtraPrice() { return extraPrice; }
    public void setExtraPrice(BigDecimal extraPrice) { this.extraPrice = extraPrice; }
}
