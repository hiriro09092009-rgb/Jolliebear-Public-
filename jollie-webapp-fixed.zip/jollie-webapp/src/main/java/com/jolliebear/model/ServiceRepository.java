package com.jolliebear.model;

import com.jolliebear.util.JPAUtil;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.List;

/**
 * Nguồn dữ liệu Dịch Vụ - đọc/ghi trực tiếp từ SQL Server qua JPA (Hibernate).
 * Nếu bảng "services" đang trống, tự động chèn dữ liệu mẫu để demo giao diện chạy được ngay.
 */
public class ServiceRepository {

    public List<ServiceItem> findAll() {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            List<ServiceItem> list = em.createQuery(
                    "SELECT s FROM ServiceItem s ORDER BY s.id", ServiceItem.class)
                    .getResultList();

            if (list.isEmpty()) {
                seedDefaultData(em);
                list = em.createQuery(
                        "SELECT s FROM ServiceItem s ORDER BY s.id", ServiceItem.class)
                        .getResultList();
            }
            return list;
        } finally {
            em.close();
        }
    }

    private void seedDefaultData(EntityManager em) {
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        em.persist(new ServiceItem(
                0, "fa-solid fa-motorcycle", "Giao Hàng Tận Nơi", "Home Delivery",
                "Đặt món yêu thích và nhận hàng ngay tại nhà chỉ trong 30 phút.",
                "Order your favorite food and get it delivered home in 30 minutes.",
                "Đặt giao hàng", "Order delivery", "service?type=delivery"
        ));

        em.persist(new ServiceItem(
                0, "fa-solid fa-bag-shopping", "Đặt Đến Lấy", "Pickup Order",
                "Đặt trước trên app, ghé cửa hàng lấy ngay, không cần chờ đợi.",
                "Pre-order on the app, then pick it up in-store with no waiting.",
                "Đặt đến lấy", "Order pickup", "service?type=pickup"
        ));

        em.persist(new ServiceItem(
                0, "fa-solid fa-champagne-glasses", "Tổ Chức Tiệc & Sự Kiện", "Parties & Events",
                "Không gian ấm cúng, phù hợp tổ chức sinh nhật, tiệc nhóm bạn bè.",
                "A cozy space perfect for birthdays and get-togethers with friends.",
                "Liên hệ đặt tiệc", "Contact us", "service?type=party"
        ));

        em.persist(new ServiceItem(
                0, "fa-solid fa-building", "Đặt Suất Ăn Doanh Nghiệp", "Corporate Catering",
                "Giải pháp suất ăn số lượng lớn cho công ty, hội nghị, sự kiện.",
                "Bulk meal solutions for companies, conferences and events.",
                "Nhận báo giá", "Get a quote", "service?type=corporate"
        ));

        em.persist(new ServiceItem(
                0, "fa-solid fa-mobile-screen-button", "Đặt Hàng Qua App", "Order via App",
                "Tải ứng dụng Jolliebear để tích điểm và nhận ưu đãi độc quyền.",
                "Download the Jolliebear app to earn points and exclusive deals.",
                "Tải ứng dụng", "Download app", "service?type=app"
        ));

        em.persist(new ServiceItem(
                0, "fa-solid fa-headset", "Hỗ Trợ Khách Hàng 24/7", "24/7 Customer Support",
                "Đội ngũ CSKH luôn sẵn sàng giải đáp mọi thắc mắc của bạn.",
                "Our support team is always ready to answer your questions.",
                "Liên hệ hotline", "Call hotline", "service?type=support"
        ));

        tx.commit();
    }
}
