package com.jolliebear.model;

import com.jolliebear.util.JPAUtil;
import com.jolliebear.util.PasswordUtil;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.NoResultException;

public class UserRepository {

    /** @return user mới tạo, hoặc null nếu email đã tồn tại. */
    public User register(String fullName, String email, String phone, String rawPassword) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            if (findByEmail(email, em) != null) {
                return null;
            }
            String salt = PasswordUtil.generateSalt();
            String hash = PasswordUtil.hash(rawPassword, salt);
            User user = new User(fullName, email.trim().toLowerCase(), phone, hash, salt);

            EntityTransaction tx = em.getTransaction();
            tx.begin();
            em.persist(user);
            tx.commit();
            return user;
        } finally {
            em.close();
        }
    }

    /** @return user nếu email + mật khẩu khớp, ngược lại null. */
    public User login(String email, String rawPassword) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            User user = findByEmail(email, em);
            if (user == null) {
                return null;
            }
            boolean ok = PasswordUtil.matches(rawPassword, user.getPasswordSalt(), user.getPasswordHash());
            return ok ? user : null;
        } finally {
            em.close();
        }
    }

    public User findById(int id) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            return em.find(User.class, id);
        } finally {
            em.close();
        }
    }

    private User findByEmail(String email, EntityManager em) {
        try {
            return em.createQuery(
                    "SELECT u FROM User u WHERE u.email = :email", User.class)
                    .setParameter("email", email.trim().toLowerCase())
                    .getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    public void updateAddress(int userId, String address) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            EntityTransaction tx = em.getTransaction();
            tx.begin();
            User user = em.find(User.class, userId);
            if (user != null) {
                user.setDefaultAddress(address);
            }
            tx.commit();
        } finally {
            em.close();
        }
    }
}
