package com.jolliebear.model;

import com.jolliebear.util.JPAUtil;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.math.BigDecimal;
import java.util.List;

/**
 * Nguồn dữ liệu Món Ăn cụ thể (dùng để đặt món kiểu Grab: chọn size / độ cay / món thêm).
 */
public class MenuItemRepository {

    public List<MenuItem> findByCategoryLink(String categoryLink) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            Long count = em.createQuery("SELECT COUNT(m) FROM MenuItem m", Long.class).getSingleResult();
            if (count == 0) {
                seedDefaultData(em);
            }
            return em.createQuery(
                    "SELECT i FROM MenuItem i JOIN FETCH i.category c " +
                    "WHERE c.link = :link ORDER BY i.id", MenuItem.class)
                    .setParameter("link", categoryLink)
                    .getResultList();
        } finally {
            em.close();
        }
    }

    public MenuItem findById(int id) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            // JOIN FETCH toàn bộ optionGroups + choices ngay trong 1 câu query,
            // để item.jsp (và ItemServlet.doPost khi đọc lại option đã chọn) có thể
            // truy cập các collection này sau khi EntityManager đã đóng, tránh
            // LazyInitializationException.
            return em.createQuery(
                    "SELECT DISTINCT i FROM MenuItem i " +
                    "JOIN FETCH i.category " +
                    "LEFT JOIN FETCH i.optionGroups g " +
                    "LEFT JOIN FETCH g.choices " +
                    "WHERE i.id = :id", MenuItem.class)
                    .setParameter("id", id)
                    .getResultStream().findFirst().orElse(null);
        } finally {
            em.close();
        }
    }

    private void seedDefaultData(EntityManager em) {
        List<MenuCategory> categories = em.createQuery(
                "SELECT m FROM MenuCategory m ORDER BY m.id", MenuCategory.class).getResultList();
        if (categories.isEmpty()) {
            return; // MenuCategoryRepository.findAll() sẽ seed danh mục trước khi trang chủ được xem lần đầu
        }

        MenuCategory chicken = findCat(categories, "menu?cat=chicken");
        MenuCategory spicy = findCat(categories, "menu?cat=spicy");
        MenuCategory spaghetti = findCat(categories, "menu?cat=spaghetti");
        MenuCategory dessert = findCat(categories, "menu?cat=dessert");

        EntityTransaction tx = em.getTransaction();
        tx.begin();

        if (chicken != null) {
            em.persist(buildChickenItem(chicken, "Gà Giòn Truyền Thống", "Classic Crispy Chicken",
                    "Gà tẩm bột giòn rụm chiên vàng, công thức bí truyền Jolliebear.",
                    "Crispy battered chicken deep-fried golden, Jolliebear's secret recipe.",
                    new BigDecimal(35000), "fa-solid fa-drumstick-bite", true));

            em.persist(buildChickenItem(chicken, "Gà Giòn Sốt Phô Mai", "Cheese Sauce Crispy Chicken",
                    "Gà giòn phủ sốt phô mai béo ngậy tan chảy.",
                    "Crispy chicken topped with rich melted cheese sauce.",
                    new BigDecimal(45000), "fa-solid fa-drumstick-bite", false));
        }

        if (spicy != null) {
            em.persist(buildSpicyItem(spicy, "Gà Sốt Cay Hàn Quốc", "Korean Spicy Chicken",
                    "Gà chiên giòn áo sốt cay ngọt kiểu Hàn Quốc.",
                    "Crispy fried chicken glazed in Korean sweet & spicy sauce.",
                    new BigDecimal(42000), "fa-solid fa-pepper-hot", true));

            em.persist(buildSpicyItem(spicy, "Cánh Gà Sốt Cay", "Spicy Chicken Wings",
                    "Cánh gà chiên giòn, sốt cay đậm đà.",
                    "Deep-fried chicken wings tossed in bold spicy sauce.",
                    new BigDecimal(38000), "fa-solid fa-fire-flame-curved", false));
        }

        if (spaghetti != null) {
            em.persist(buildSpaghettiItem(spaghetti, "Mỳ Ý Sốt Bò Bằm", "Spaghetti Bolognese",
                    "Mỳ Ý sốt thịt bò bằm đậm đà, phô mai bào phủ trên.",
                    "Spaghetti with rich minced beef sauce, topped with grated cheese.",
                    new BigDecimal(39000), "fa-solid fa-bowl-food", true));

            em.persist(buildSpaghettiItem(spaghetti, "Mỳ Ý Sốt Kem Nấm", "Creamy Mushroom Spaghetti",
                    "Mỳ Ý sốt kem nấm béo mịn, thơm bơ tỏi.",
                    "Spaghetti in creamy mushroom sauce with garlic butter aroma.",
                    new BigDecimal(39000), "fa-solid fa-bowl-food", false));
        }

        if (dessert != null) {
            em.persist(buildDessertItem(dessert, "Kem Ốc Quế Vani", "Vanilla Soft Cone",
                    "Kem vani mềm mịn, mát lạnh giải nhiệt.",
                    "Soft, creamy vanilla ice cream cone.",
                    new BigDecimal(15000), "fa-solid fa-ice-cream", false));

            em.persist(buildDessertItem(dessert, "Bánh Trứng Nướng", "Baked Egg Tart",
                    "Bánh trứng nướng vỏ giòn, nhân béo thơm.",
                    "Crispy egg tart with a rich, fragrant custard filling.",
                    new BigDecimal(18000), "fa-solid fa-cookie", false));
        }

        tx.commit();
    }

    private MenuCategory findCat(List<MenuCategory> categories, String link) {
        return categories.stream().filter(c -> link.equals(c.getLink())).findFirst().orElse(null);
    }

    private MenuItem buildChickenItem(MenuCategory cat, String name, String nameEn, String desc, String descEn,
                                       BigDecimal price, String icon, boolean best) {
        MenuItem item = new MenuItem(cat, name, nameEn, desc, descEn, price, icon, best);

        OptionGroup size = new OptionGroup("Chọn số lượng", "Choose quantity", true, false, 1);
        size.addChoice(new OptionChoice("1 Miếng", "1 Piece", BigDecimal.ZERO, true));
        size.addChoice(new OptionChoice("2 Miếng", "2 Pieces", new BigDecimal(30000), false));
        size.addChoice(new OptionChoice("3 Miếng", "3 Pieces", new BigDecimal(58000), false));
        item.addOptionGroup(size);

        OptionGroup spice = new OptionGroup("Độ cay", "Spice level", true, false, 2);
        spice.addChoice(new OptionChoice("Không cay", "Not spicy", BigDecimal.ZERO, true));
        spice.addChoice(new OptionChoice("Cay vừa", "Medium spicy", BigDecimal.ZERO, false));
        spice.addChoice(new OptionChoice("Cay nhiều", "Extra spicy", BigDecimal.ZERO, false));
        item.addOptionGroup(spice);

        OptionGroup addon = new OptionGroup("Món thêm", "Add-ons", false, true, 3);
        addon.addChoice(new OptionChoice("Khoai tây chiên", "French fries", new BigDecimal(15000), false));
        addon.addChoice(new OptionChoice("Nước ngọt size vừa", "Medium soft drink", new BigDecimal(10000), false));
        addon.addChoice(new OptionChoice("Cơm trắng", "Steamed rice", new BigDecimal(8000), false));
        item.addOptionGroup(addon);

        return item;
    }

    private MenuItem buildSpicyItem(MenuCategory cat, String name, String nameEn, String desc, String descEn,
                                     BigDecimal price, String icon, boolean best) {
        MenuItem item = new MenuItem(cat, name, nameEn, desc, descEn, price, icon, best);

        OptionGroup spice = new OptionGroup("Độ cay", "Spice level", true, false, 1);
        spice.addChoice(new OptionChoice("Cay vừa", "Medium spicy", BigDecimal.ZERO, true));
        spice.addChoice(new OptionChoice("Cay nhiều", "Extra spicy", new BigDecimal(0), false));
        spice.addChoice(new OptionChoice("Siêu cay", "Super spicy", new BigDecimal(5000), false));
        item.addOptionGroup(spice);

        OptionGroup addon = new OptionGroup("Món thêm", "Add-ons", false, true, 2);
        addon.addChoice(new OptionChoice("Thêm phô mai", "Extra cheese", new BigDecimal(8000), false));
        addon.addChoice(new OptionChoice("Khoai tây chiên", "French fries", new BigDecimal(15000), false));
        item.addOptionGroup(addon);

        return item;
    }

    private MenuItem buildSpaghettiItem(MenuCategory cat, String name, String nameEn, String desc, String descEn,
                                         BigDecimal price, String icon, boolean best) {
        MenuItem item = new MenuItem(cat, name, nameEn, desc, descEn, price, icon, best);

        OptionGroup size = new OptionGroup("Kích cỡ", "Portion size", true, false, 1);
        size.addChoice(new OptionChoice("Phần thường", "Regular", BigDecimal.ZERO, true));
        size.addChoice(new OptionChoice("Phần lớn", "Large", new BigDecimal(12000), false));
        item.addOptionGroup(size);

        OptionGroup addon = new OptionGroup("Món thêm", "Add-ons", false, true, 2);
        addon.addChoice(new OptionChoice("Phô mai bào thêm", "Extra grated cheese", new BigDecimal(7000), false));
        addon.addChoice(new OptionChoice("Bánh mì bơ tỏi", "Garlic bread", new BigDecimal(12000), false));
        item.addOptionGroup(addon);

        return item;
    }

    private MenuItem buildDessertItem(MenuCategory cat, String name, String nameEn, String desc, String descEn,
                                       BigDecimal price, String icon, boolean best) {
        MenuItem item = new MenuItem(cat, name, nameEn, desc, descEn, price, icon, best);

        OptionGroup topping = new OptionGroup("Topping", "Topping", false, true, 1);
        topping.addChoice(new OptionChoice("Socola chip", "Chocolate chips", new BigDecimal(5000), false));
        topping.addChoice(new OptionChoice("Hạt hạnh nhân", "Almonds", new BigDecimal(6000), false));
        item.addOptionGroup(topping);

        return item;
    }
}
