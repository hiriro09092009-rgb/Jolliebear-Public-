package com.jolliebear.model;

import jakarta.persistence.*;

import java.math.BigDecimal;

/**
 * 1 lựa chọn cụ thể bên trong 1 OptionGroup, VD "Size L (+10.000đ)", "Cay vừa", "Thêm phô mai (+8.000đ)".
 */
@Entity
@Table(name = "option_choices")
public class OptionChoice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "option_group_id")
    private OptionGroup optionGroup;

    @Column(columnDefinition = "NVARCHAR(200) NOT NULL")
    private String name;
    @Column(columnDefinition = "NVARCHAR(200)")
    private String nameEn;

    @Column(nullable = false, precision = 12, scale = 0)
    private BigDecimal extraPrice = BigDecimal.ZERO;

    private boolean isDefault = false;

    public OptionChoice() {
    }

    public OptionChoice(String name, String nameEn, BigDecimal extraPrice, boolean isDefault) {
        this.name = name;
        this.nameEn = nameEn;
        this.extraPrice = extraPrice;
        this.isDefault = isDefault;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public OptionGroup getOptionGroup() { return optionGroup; }
    public void setOptionGroup(OptionGroup optionGroup) { this.optionGroup = optionGroup; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getNameEn() { return nameEn; }
    public void setNameEn(String nameEn) { this.nameEn = nameEn; }

    public BigDecimal getExtraPrice() { return extraPrice; }
    public void setExtraPrice(BigDecimal extraPrice) { this.extraPrice = extraPrice; }

    public boolean isDefault() { return isDefault; }
    public void setDefault(boolean aDefault) { isDefault = aDefault; }

    public String getDisplayName(String lang) {
        return ("en".equals(lang) && nameEn != null && !nameEn.isBlank()) ? nameEn : name;
    }
}
