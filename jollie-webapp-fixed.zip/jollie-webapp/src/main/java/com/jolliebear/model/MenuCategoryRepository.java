package com.jolliebear.model;

import com.jolliebear.util.JPAUtil;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.List;

/**
 * Nguồn dữ liệu Danh Mục Món Ăn - đọc/ghi trực tiếp từ SQL Server qua JPA (Hibernate).
 * Nếu bảng "menu_categories" đang trống, tự động chèn dữ liệu mẫu để demo giao diện chạy được ngay.
 */
public class MenuCategoryRepository {

    public List<MenuCategory> findAll() {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            List<MenuCategory> list = em.createQuery(
                    "SELECT m FROM MenuCategory m ORDER BY m.id", MenuCategory.class)
                    .getResultList();

            if (list.isEmpty()) {
                seedDefaultData(em);
                list = em.createQuery(
                        "SELECT m FROM MenuCategory m ORDER BY m.id", MenuCategory.class)
                        .getResultList();
            }
            return list;
        } finally {
            em.close();
        }
    }

    public MenuCategory findByLink(String link) {
        EntityManager em = JPAUtil.getEntityManager();
        try {
            return em.createQuery(
                    "SELECT m FROM MenuCategory m WHERE m.link = :link", MenuCategory.class)
                    .setParameter("link", link)
                    .getResultStream().findFirst().orElse(null);
        } finally {
            em.close();
        }
    }

    private void seedDefaultData(EntityManager em) {
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        em.persist(new MenuCategory(0, "fa-solid fa-drumstick-bite", "chicken-mock",
                "Gà Giòn Vui Vẻ", "Crispy Fried Chicken",
                "Thơm giòn rụm bên ngoài, mọng nước bên trong.",
                "Crispy on the outside, juicy on the inside.", "menu?cat=chicken"));

        em.persist(new MenuCategory(0, "fa-solid fa-fire-flame-curved", "spicy-mock",
                "Gà Sốt Cay & Ngọt", "Spicy & Sweet Chicken",
                "Sốt đặc trưng thấm sâu cay tê kích thích vị giác.",
                "Signature sauce, spicy-sweet and packed with flavor.", "menu?cat=spicy"));

        em.persist(new MenuCategory(0, "fa-solid fa-bowl-food", "spaghetti-mock",
                "Mỳ Ý Sốt Bò Bằm", "Spaghetti Bolognese",
                "Mỳ dai mềm kết hợp sốt thịt băm đậm đà.",
                "Chewy pasta with rich minced beef sauce.", "menu?cat=spaghetti"));

        em.persist(new MenuCategory(0, "fa-solid fa-ice-cream", "dessert-mock",
                "Tráng Miệng Ngọt Ngào", "Sweet Desserts",
                "Kem tươi mát lạnh, giải nhiệt ngày hè.",
                "Cool, creamy desserts to beat the heat.", "menu?cat=dessert"));

        tx.commit();
    }
}
