package com.jolliebear.cart;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * 1 dòng trong giỏ hàng: 1 món ăn đã chọn xong tùy chọn (size, độ cay, món thêm...),
 * kèm số lượng. Giống 1 "item" trong giỏ hàng GrabFood sau khi bấm "Thêm vào giỏ".
 */
public class CartLine implements Serializable {

    public static class ChosenOption implements Serializable {
        public final String groupName;
        public final String choiceName;
        public final BigDecimal extraPrice;

        public ChosenOption(String groupName, String choiceName, BigDecimal extraPrice) {
            this.groupName = groupName;
            this.choiceName = choiceName;
            this.extraPrice = extraPrice;
        }
    }

    private final String lineId;   // id duy nhất cho dòng này trong giỏ (để sửa/xoá đúng dòng)
    private final int menuItemId;
    private final String itemName;
    private final String iconClass;
    private final BigDecimal unitBasePrice;
    private final List<ChosenOption> options = new ArrayList<>();
    private int quantity;
    private String note;

    public CartLine(String lineId, int menuItemId, String itemName, String iconClass, BigDecimal unitBasePrice, int quantity, String note) {
        this.lineId = lineId;
        this.menuItemId = menuItemId;
        this.itemName = itemName;
        this.iconClass = iconClass;
        this.unitBasePrice = unitBasePrice;
        this.quantity = quantity;
        this.note = note;
    }

    public void addOption(ChosenOption option) {
        options.add(option);
    }

    public String getLineId() { return lineId; }
    public int getMenuItemId() { return menuItemId; }
    public String getItemName() { return itemName; }
    public String getIconClass() { return iconClass; }
    public BigDecimal getUnitBasePrice() { return unitBasePrice; }
    public List<ChosenOption> getOptions() { return options; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }

    /** Đơn giá 1 phần = giá gốc + tổng phụ phí các tùy chọn đã chọn. */
    public BigDecimal getUnitPrice() {
        BigDecimal total = unitBasePrice;
        for (ChosenOption o : options) {
            total = total.add(o.extraPrice);
        }
        return total;
    }

    public BigDecimal getLineTotal() {
        return getUnitPrice().multiply(BigDecimal.valueOf(quantity));
    }

    public String getOptionsSummary() {
        StringBuilder sb = new StringBuilder();
        for (ChosenOption o : options) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(o.choiceName);
        }
        return sb.toString();
    }
}
