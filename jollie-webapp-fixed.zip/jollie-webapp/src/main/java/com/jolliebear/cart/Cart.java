package com.jolliebear.cart;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Giỏ hàng - lưu trong HttpSession (attribute "cart"), tồn tại trong suốt phiên
 * làm việc của khách, không cần đăng nhập mới thêm được vào giỏ (giống Grab:
 * chỉ bắt buộc đăng nhập ở bước thanh toán).
 */
public class Cart implements Serializable {

    private final List<CartLine> lines = new ArrayList<>();

    public String addLine(int menuItemId, String itemName, String iconClass, BigDecimal unitBasePrice,
                           int quantity, String note, List<CartLine.ChosenOption> options) {
        String lineId = UUID.randomUUID().toString();
        CartLine line = new CartLine(lineId, menuItemId, itemName, iconClass, unitBasePrice, quantity, note);
        for (CartLine.ChosenOption o : options) {
            line.addOption(o);
        }
        lines.add(line);
        return lineId;
    }

    public void updateQuantity(String lineId, int quantity) {
        for (CartLine line : lines) {
            if (line.getLineId().equals(lineId)) {
                if (quantity <= 0) {
                    lines.remove(line);
                } else {
                    line.setQuantity(quantity);
                }
                return;
            }
        }
    }

    public void removeLine(String lineId) {
        lines.removeIf(l -> l.getLineId().equals(lineId));
    }

    public void clear() {
        lines.clear();
    }

    public List<CartLine> getLines() {
        return lines;
    }

    public boolean isEmpty() {
        return lines.isEmpty();
    }

    public int getTotalQuantity() {
        return lines.stream().mapToInt(CartLine::getQuantity).sum();
    }

    public BigDecimal getSubtotal() {
        BigDecimal total = BigDecimal.ZERO;
        for (CartLine line : lines) {
            total = total.add(line.getLineTotal());
        }
        return total;
    }
}
