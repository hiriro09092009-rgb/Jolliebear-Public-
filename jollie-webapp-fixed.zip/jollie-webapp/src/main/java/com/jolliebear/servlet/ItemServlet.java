package com.jolliebear.servlet;

import com.jolliebear.cart.Cart;
import com.jolliebear.cart.CartLine;
import com.jolliebear.model.MenuItem;
import com.jolliebear.model.MenuItemRepository;
import com.jolliebear.model.OptionChoice;
import com.jolliebear.model.OptionGroup;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Trang chi tiết 1 món ăn: chọn size / độ cay / món thêm rồi thêm vào giỏ - giống
 * màn hình chi tiết món trên GrabFood. Mapping: /item?id=xx
 */
@WebServlet(name = "ItemServlet", urlPatterns = {"/item"})
public class ItemServlet extends HttpServlet {

    private final MenuItemRepository menuItemRepository = new MenuItemRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = parseId(request.getParameter("id"));
        MenuItem item = id > 0 ? menuItemRepository.findById(id) : null;

        if (item == null) {
            request.setAttribute("itemNotFound", true);
        } else {
            request.setAttribute("item", item);
        }
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/item.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = parseId(request.getParameter("id"));
        MenuItem item = id > 0 ? menuItemRepository.findById(id) : null;
        if (item == null) {
            request.setAttribute("itemNotFound", true);
            request.getRequestDispatcher("/WEB-INF/views/item.jsp").forward(request, response);
            return;
        }

        int quantity = Math.max(1, parseId(request.getParameter("quantity")));
        String note = request.getParameter("note");

        List<CartLine.ChosenOption> chosen = new ArrayList<>();
        for (OptionGroup group : item.getOptionGroups()) {
            String paramName = "group_" + group.getId();
            String[] values = request.getParameterValues(paramName);

            if (group.isRequired() && (values == null || values.length == 0)) {
                request.setAttribute("item", item);
                request.setAttribute("errorKey", "item.required");
                request.getRequestDispatcher("/WEB-INF/views/item.jsp").forward(request, response);
                return;
            }

            if (values != null) {
                for (String v : values) {
                    int choiceId = parseId(v);
                    for (OptionChoice choice : group.getChoices()) {
                        if (choice.getId() == choiceId) {
                            chosen.add(new CartLine.ChosenOption(
                                    group.getName(), choice.getName(), choice.getExtraPrice()));
                        }
                    }
                }
            }
        }

        HttpSession session = request.getSession(true);
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) {
            cart = new Cart();
            session.setAttribute("cart", cart);
        }
        cart.addLine(item.getId(), item.getName(), item.getIconClass(), item.getBasePrice(), quantity, note, chosen);

        response.sendRedirect(request.getContextPath() + "/cart");
    }

    private int parseId(String s) {
        try {
            return s == null ? 0 : Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
