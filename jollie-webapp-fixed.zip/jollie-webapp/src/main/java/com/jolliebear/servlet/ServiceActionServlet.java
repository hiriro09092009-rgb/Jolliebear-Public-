package com.jolliebear.servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Xử lý khi người dùng bấm vào 1 dịch vụ cụ thể (Giao hàng, Đặt đến lấy, Tổ chức tiệc...).
 * Mapping: /service?type=delivery|pickup|party|corporate|app|support
 * Thông báo được tra theo key i18n (messages_vi/messages_en.properties) để hiển thị đúng ngôn ngữ đang chọn.
 */
@WebServlet(name = "ServiceActionServlet", urlPatterns = {"/service"})
public class ServiceActionServlet extends HttpServlet {

    private static final Map<String, String> SERVICE_MESSAGE_KEYS = new HashMap<>();
    static {
        SERVICE_MESSAGE_KEYS.put("delivery", "service.delivery");
        SERVICE_MESSAGE_KEYS.put("pickup", "service.pickup");
        SERVICE_MESSAGE_KEYS.put("party", "service.party");
        SERVICE_MESSAGE_KEYS.put("corporate", "service.corporate");
        SERVICE_MESSAGE_KEYS.put("app", "service.app");
        SERVICE_MESSAGE_KEYS.put("support", "service.support");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String type = request.getParameter("type");
        String messageKey = SERVICE_MESSAGE_KEYS.getOrDefault(type, "service.unknown");

        request.setAttribute("serviceType", type);
        request.setAttribute("serviceMessageKey", messageKey);

        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/serviceResult.jsp");
        dispatcher.forward(request, response);
    }
}
