package com.jolliebear.servlet;

import com.jolliebear.model.Order;
import com.jolliebear.model.OrderRepository;
import com.jolliebear.model.User;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "OrderHistoryServlet", urlPatterns = {"/orders"})
public class OrderHistoryServlet extends HttpServlet {

    private final OrderRepository orderRepository = new OrderRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User user = session == null ? null : (User) session.getAttribute(LoginServlet.SESSION_USER_KEY);
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login?redirect=/orders");
            return;
        }

        List<Order> orders = orderRepository.findByUser(user.getId());
        request.setAttribute("orders", orders);

        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/orders.jsp");
        dispatcher.forward(request, response);
    }
}
