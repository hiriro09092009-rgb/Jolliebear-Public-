package com.jolliebear.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * Đổi ngôn ngữ giao diện: /lang?code=vi|en&back=/home
 * Ghi cookie "lang" (tồn tại 1 năm) rồi quay lại trang trước đó.
 */
@WebServlet(name = "LanguageServlet", urlPatterns = {"/lang"})
public class LanguageServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String code = request.getParameter("code");
        if (!"en".equals(code)) {
            code = "vi"; // mặc định / bảo vệ khỏi giá trị lạ
        }

        Cookie langCookie = new Cookie("lang", code);
        langCookie.setPath("/");
        langCookie.setMaxAge(60 * 60 * 24 * 365);
        response.addCookie(langCookie);

        String back = request.getParameter("back");
        if (back == null || back.isBlank() || !back.startsWith("/")) {
            back = request.getContextPath() + "/home";
        }
        response.sendRedirect(back);
    }
}
