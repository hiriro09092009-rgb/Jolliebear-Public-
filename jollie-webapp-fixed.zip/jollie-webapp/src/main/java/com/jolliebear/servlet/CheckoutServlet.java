package com.jolliebear.servlet;

import com.jolliebear.cart.Cart;
import com.jolliebear.cart.CartLine;
import com.jolliebear.model.MenuItem;
import com.jolliebear.model.MenuItemRepository;
import com.jolliebear.model.Order;
import com.jolliebear.model.OrderItem;
import com.jolliebear.model.OrderItemOption;
import com.jolliebear.model.OrderRepository;
import com.jolliebear.model.User;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;

/**
 * Thanh toán / đặt hàng. Mapping: /checkout
 * Bắt buộc đăng nhập (giống Grab: có thể duyệt món và thêm giỏ tự do,
 * nhưng phải đăng nhập mới đặt hàng được).
 */
@WebServlet(name = "CheckoutServlet", urlPatterns = {"/checkout"})
public class CheckoutServlet extends HttpServlet {

    private static final BigDecimal FREE_SHIP_THRESHOLD = new BigDecimal(99000);
    private static final BigDecimal SHIPPING_FEE = new BigDecimal(15000);

    private final OrderRepository orderRepository = new OrderRepository();
    private final MenuItemRepository menuItemRepository = new MenuItemRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        User user = currentUser(request);
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login?redirect=/checkout");
            return;
        }

        Cart cart = getCart(request);
        if (cart.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/cart");
            return;
        }

        request.setAttribute("cart", cart);
        request.setAttribute("user", user);
        request.setAttribute("shippingFee", shippingFee(cart, "delivery"));
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/checkout.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        User user = currentUser(request);
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login?redirect=/checkout");
            return;
        }

        Cart cart = getCart(request);
        if (cart.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/cart");
            return;
        }

        String orderTypeParam = request.getParameter("orderType");
        Order.OrderType orderType = "pickup".equals(orderTypeParam) ? Order.OrderType.PICKUP : Order.OrderType.DELIVERY;
        String address = request.getParameter("address");
        String phone = request.getParameter("phone");
        String note = request.getParameter("note");

        if (orderType == Order.OrderType.DELIVERY && (address == null || address.isBlank())) {
            request.setAttribute("cart", cart);
            request.setAttribute("user", user);
            request.setAttribute("shippingFee", shippingFee(cart, orderTypeParam));
            request.setAttribute("errorKey", "checkout.address");
            request.getRequestDispatcher("/WEB-INF/views/checkout.jsp").forward(request, response);
            return;
        }

        BigDecimal subtotal = cart.getSubtotal();
        BigDecimal shipping = shippingFee(cart, orderTypeParam);

        Order order = new Order();
        order.setUser(user);
        order.setOrderType(orderType);
        order.setDeliveryAddress(orderType == Order.OrderType.DELIVERY ? address : null);
        order.setContactPhone(phone == null || phone.isBlank() ? user.getPhone() : phone);
        order.setNote(note);
        order.setSubtotal(subtotal);
        order.setShippingFee(shipping);
        order.setTotal(subtotal.add(shipping));

        for (CartLine line : cart.getLines()) {
            MenuItem menuItem = menuItemRepository.findById(line.getMenuItemId());
            OrderItem orderItem = new OrderItem();
            orderItem.setMenuItem(menuItem);
            orderItem.setItemName(line.getItemName());
            orderItem.setUnitPrice(line.getUnitPrice());
            orderItem.setQuantity(line.getQuantity());
            orderItem.setLineTotal(line.getLineTotal());
            orderItem.setNote(line.getNote());
            for (CartLine.ChosenOption opt : line.getOptions()) {
                orderItem.addOption(new OrderItemOption(opt.groupName, opt.choiceName, opt.extraPrice));
            }
            order.addItem(orderItem);
        }

        Order saved = orderRepository.save(order);
        cart.clear();

        response.sendRedirect(request.getContextPath() + "/order-confirmation?orderId=" + saved.getId());
    }

    private BigDecimal shippingFee(Cart cart, String orderType) {
        if ("pickup".equals(orderType)) {
            return BigDecimal.ZERO;
        }
        return cart.getSubtotal().compareTo(FREE_SHIP_THRESHOLD) >= 0 ? BigDecimal.ZERO : SHIPPING_FEE;
    }

    private User currentUser(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        return session == null ? null : (User) session.getAttribute(LoginServlet.SESSION_USER_KEY);
    }

    private Cart getCart(HttpServletRequest request) {
        HttpSession session = request.getSession(true);
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) {
            cart = new Cart();
            session.setAttribute("cart", cart);
        }
        return cart;
    }
}
