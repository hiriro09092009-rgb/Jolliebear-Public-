package com.jolliebear.servlet;

import com.jolliebear.cart.Cart;
import com.jolliebear.model.MenuCategory;
import com.jolliebear.model.MenuCategoryRepository;
import com.jolliebear.model.Promotion;
import com.jolliebear.model.PromotionRepository;
import com.jolliebear.model.ServiceItem;
import com.jolliebear.model.ServiceRepository;
import com.jolliebear.model.User;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

/**
 * Servlet chính, render trang chủ (Hero, Đặt hàng, Thực Đơn, Khuyến Mãi, Dịch Vụ) qua index.jsp.
 *
 * QUAN TRỌNG: KHÔNG map servlet này vào "/".
 * Trong Servlet spec, url-pattern "/" biến servlet thành "default servlet",
 * nó sẽ chặn luôn mọi request tĩnh (css, js, ảnh...) khiến trình duyệt
 * nhận về HTML thay vì file CSS/JS thật -> mất giao diện hoàn toàn.
 * Vì vậy chỉ map "/home"; còn "/" do welcome-file (index.jsp) redirect sang đây.
 */
@WebServlet(name = "HomeServlet", urlPatterns = {"/home"})
public class HomeServlet extends HttpServlet {

    private final MenuCategoryRepository menuCategoryRepository = new MenuCategoryRepository();
    private final PromotionRepository promotionRepository = new PromotionRepository();
    private final ServiceRepository serviceRepository = new ServiceRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. Danh mục thực đơn ("Ăn Gì Hôm Nay")
        List<MenuCategory> menuCategories = menuCategoryRepository.findAll();
        request.setAttribute("menuCategories", menuCategories);

        // 2. Khuyến mãi
        List<Promotion> promotions = promotionRepository.findAll();
        request.setAttribute("promotions", promotions);

        // 3. Dịch vụ
        List<ServiceItem> services = serviceRepository.findAll();
        request.setAttribute("services", services);

        // 4. Người dùng hiện tại (nếu đã đăng nhập) + số lượng món trong giỏ hàng
        HttpSession session = request.getSession(false);
        User currentUser = session == null ? null : (User) session.getAttribute(LoginServlet.SESSION_USER_KEY);
        Cart cart = session == null ? null : (Cart) session.getAttribute("cart");
        request.setAttribute("currentUser", currentUser);
        request.setAttribute("cartCount", cart == null ? 0 : cart.getTotalQuantity());

        // 5. Forward sang JSP thật (nằm trong WEB-INF nên không thể truy cập trực tiếp bằng URL)
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/index.jsp");
        dispatcher.forward(request, response);
    }
}

