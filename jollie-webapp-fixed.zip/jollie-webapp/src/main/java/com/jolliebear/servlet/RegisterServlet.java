package com.jolliebear.servlet;

import com.jolliebear.model.User;
import com.jolliebear.model.UserRepository;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

/**
 * Đăng ký tài khoản mới. Mapping: /register
 * GET  -> hiển thị form đăng ký (register.jsp)
 * POST -> tạo user mới (mật khẩu được băm bằng PBKDF2, xem UserRepository/PasswordUtil)
 */
@WebServlet(name = "RegisterServlet", urlPatterns = {"/register"})
public class RegisterServlet extends HttpServlet {

    private final UserRepository userRepository = new UserRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String fullName = trim(request.getParameter("fullName"));
        String email = trim(request.getParameter("email"));
        String phone = trim(request.getParameter("phone"));
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");

        // Giữ lại giá trị đã nhập để hiển thị lại nếu có lỗi (trừ mật khẩu)
        request.setAttribute("fullName", fullName);
        request.setAttribute("email", email);
        request.setAttribute("phone", phone);

        if (isBlank(fullName) || isBlank(email) || isBlank(phone) || isBlank(password)) {
            request.setAttribute("error", "missing_fields");
            forward(request, response);
            return;
        }

        if (!password.equals(confirmPassword)) {
            request.setAttribute("errorKey", "auth.error_password_mismatch");
            forward(request, response);
            return;
        }

        User created = userRepository.register(fullName, email, phone, password);
        if (created == null) {
            request.setAttribute("errorKey", "auth.error_email_exists");
            forward(request, response);
            return;
        }

        response.sendRedirect(request.getContextPath() + "/login?registered=1");
    }

    private void forward(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/register.jsp");
        dispatcher.forward(request, response);
    }

    private static String trim(String s) { return s == null ? null : s.trim(); }
    private static boolean isBlank(String s) { return s == null || s.isBlank(); }
}
