package com.jolliebear.servlet;

import com.jolliebear.model.User;
import com.jolliebear.model.UserRepository;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Đăng nhập. Mapping: /login
 * GET  -> hiển thị form đăng nhập (login.jsp). Hỗ trợ ?redirect=/checkout để
 *         quay lại đúng trang khách đang muốn vào sau khi đăng nhập (VD từ giỏ hàng).
 * POST -> kiểm tra email/mật khẩu, nếu đúng thì lưu User vào session ("authUser").
 */
@WebServlet(name = "LoginServlet", urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet {

    public static final String SESSION_USER_KEY = "authUser";

    private final UserRepository userRepository = new UserRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String redirect = request.getParameter("redirect");

        request.setAttribute("email", email);

        User user = userRepository.login(email == null ? "" : email.trim(), password == null ? "" : password);
        if (user == null) {
            request.setAttribute("errorKey", "auth.error_login");
            RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/login.jsp");
            dispatcher.forward(request, response);
            return;
        }

        HttpSession session = request.getSession(true);
        session.setAttribute(SESSION_USER_KEY, user);

        if (redirect == null || redirect.isBlank() || !redirect.startsWith("/")) {
            redirect = "/home";
        }
        response.sendRedirect(request.getContextPath() + redirect);
    }
}
