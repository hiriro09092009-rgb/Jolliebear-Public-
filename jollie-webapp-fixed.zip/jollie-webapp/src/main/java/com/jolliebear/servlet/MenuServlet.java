package com.jolliebear.servlet;

import com.jolliebear.model.MenuCategory;
import com.jolliebear.model.MenuCategoryRepository;
import com.jolliebear.model.MenuItem;
import com.jolliebear.model.MenuItemRepository;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

/**
 * Hiển thị danh sách món ăn thật của 1 danh mục (giống trang danh mục món trên GrabFood).
 * Mapping: /menu?cat=chicken|spicy|spaghetti|dessert
 */
@WebServlet(name = "MenuServlet", urlPatterns = {"/menu"})
public class MenuServlet extends HttpServlet {

    private final MenuCategoryRepository categoryRepository = new MenuCategoryRepository();
    private final MenuItemRepository menuItemRepository = new MenuItemRepository();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String cat = request.getParameter("cat");
        String link = "menu?cat=" + cat;

        // Gọi findAll() trước để đảm bảo danh mục đã được seed (nếu đây là lượt truy cập
        // đầu tiên vào /menu mà chưa từng ghé trang chủ /home).
        List<MenuCategory> allCategories = categoryRepository.findAll();
        MenuCategory category = allCategories.stream()
                .filter(c -> link.equals(c.getLink()))
                .findFirst().orElse(null);

        List<MenuItem> items = menuItemRepository.findByCategoryLink(link);

        request.setAttribute("category", category);
        request.setAttribute("items", items);

        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/menuResult.jsp");
        dispatcher.forward(request, response);
    }
}
