package com.jolliebear.servlet;

import com.jolliebear.cart.Cart;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

/**
 * Xem / cập nhật giỏ hàng. Mapping: /cart
 * POST action=update  -> đổi số lượng 1 dòng (lineId, quantity)
 * POST action=remove   -> xoá 1 dòng (lineId)
 */
@WebServlet(name = "CartServlet", urlPatterns = {"/cart"})
public class CartServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Cart cart = getCart(request);
        request.setAttribute("cart", cart);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/cart.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Cart cart = getCart(request);
        String action = request.getParameter("action");
        String lineId = request.getParameter("lineId");

        if ("update".equals(action) && lineId != null) {
            int qty = parseInt(request.getParameter("quantity"));
            cart.updateQuantity(lineId, qty);
        } else if ("remove".equals(action) && lineId != null) {
            cart.removeLine(lineId);
        }

        response.sendRedirect(request.getContextPath() + "/cart");
    }

    private Cart getCart(HttpServletRequest request) {
        HttpSession session = request.getSession(true);
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) {
            cart = new Cart();
            session.setAttribute("cart", cart);
        }
        return cart;
    }

    private int parseInt(String s) {
        try {
            return s == null ? 0 : Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
