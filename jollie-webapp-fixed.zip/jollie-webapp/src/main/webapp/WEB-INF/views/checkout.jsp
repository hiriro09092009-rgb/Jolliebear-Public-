<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<fmt:setLocale value="${lang}" scope="request"/>
<fmt:setBundle basename="i18n.messages" scope="request"/>
<!DOCTYPE html>
<html lang="${lang}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jolliebear - <fmt:message key="checkout.title"/></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
    <jsp:include page="/WEB-INF/views/common/header.jsp"/>

    <section class="checkout-section">
        <div class="checkout-container">
            <h2><fmt:message key="checkout.title"/></h2>

            <c:if test="${not empty errorKey}">
                <div class="auth-alert auth-alert-error"><fmt:message key="${errorKey}"/></div>
            </c:if>

            <div class="checkout-grid">
                <form method="post" action="${pageContext.request.contextPath}/checkout" class="checkout-form" id="checkout-form">
                    <div class="option-group">
                        <h4><fmt:message key="checkout.order_type"/></h4>
                        <label class="option-choice">
                            <input type="radio" name="orderType" value="delivery" checked>
                            <span class="option-choice-name"><fmt:message key="checkout.delivery"/></span>
                        </label>
                        <label class="option-choice">
                            <input type="radio" name="orderType" value="pickup">
                            <span class="option-choice-name"><fmt:message key="checkout.pickup"/></span>
                        </label>
                    </div>

                    <label class="auth-label" id="address-field">
                        <fmt:message key="checkout.address"/>
                        <input type="text" name="address" value="${user.defaultAddress}">
                    </label>

                    <label class="auth-label">
                        <fmt:message key="checkout.phone"/>
                        <input type="tel" name="phone" value="${user.phone}">
                    </label>

                    <label class="auth-label">
                        <fmt:message key="checkout.note"/>
                        <textarea name="note" rows="2"></textarea>
                    </label>

                    <button type="submit" class="btn btn-primary btn-block"><fmt:message key="checkout.place_order"/></button>
                </form>

                <div class="checkout-summary">
                    <c:forEach items="${cart.lines}" var="line">
                        <div class="checkout-summary-line">
                            <span>${line.quantity} x ${line.itemName}</span>
                            <strong><fmt:formatNumber value="${line.lineTotal}" type="number"/>đ</strong>
                        </div>
                    </c:forEach>
                    <hr>
                    <div class="checkout-summary-line">
                        <span><fmt:message key="cart.subtotal"/></span>
                        <span><fmt:formatNumber value="${cart.subtotal}" type="number"/>đ</span>
                    </div>
                    <div class="checkout-summary-line">
                        <span><fmt:message key="checkout.shipping_fee"/></span>
                        <span><fmt:formatNumber value="${shippingFee}" type="number"/>đ</span>
                    </div>
                    <div class="checkout-summary-line checkout-total">
                        <span><fmt:message key="checkout.total"/></span>
                        <strong><fmt:formatNumber value="${cart.subtotal + shippingFee}" type="number"/>đ</strong>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <jsp:include page="/WEB-INF/views/common/footer.jsp"/>
    <script src="${pageContext.request.contextPath}/js/main.js"></script>
</body>
</html>
