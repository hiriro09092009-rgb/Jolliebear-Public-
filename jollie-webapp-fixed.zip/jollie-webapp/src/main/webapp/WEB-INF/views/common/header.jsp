<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<fmt:setLocale value="${lang}" scope="request"/>
<fmt:setBundle basename="i18n.messages" scope="request"/>
<%--
  Fragment dùng chung cho mọi trang: thanh tiện ích trên cùng (đổi ngôn ngữ,
  đăng nhập/đăng ký) + header chính (logo, menu điều hướng, icon giỏ hàng).
  Include bằng <jsp:include page="/WEB-INF/views/common/header.jsp"/>
--%>
<c:set var="currentUrl" value="${pageContext.request.requestURI}"/>

<div class="utility-bar">
    <div class="utility-container">
        <div class="utility-left"><span><fmt:message key="site.welcome"/></span></div>
        <div class="utility-right">
            <div class="language-selector">
                <a class="lang-item ${lang == 'vi' ? 'active' : ''}"
                   href="${pageContext.request.contextPath}/lang?code=vi&back=${currentUrl}">
                    <span class="flag-icon vi-flag"></span> VN
                </a>
                <a class="lang-item ${lang == 'en' ? 'active' : ''}"
                   href="${pageContext.request.contextPath}/lang?code=en&back=${currentUrl}">
                    <span class="flag-icon en-flag"></span> EN
                </a>
            </div>

            <c:choose>
                <c:when test="${not empty sessionScope.authUser}">
                    <a href="${pageContext.request.contextPath}/orders" class="auth-btn">
                        <i class="fa-regular fa-user"></i>
                        <span><fmt:message key="auth.hello"/> ${sessionScope.authUser.fullName}</span>
                    </a>
                    <a href="${pageContext.request.contextPath}/logout" class="auth-btn">
                        <i class="fa-solid fa-right-from-bracket"></i>
                        <span><fmt:message key="auth.logout"/></span>
                    </a>
                </c:when>
                <c:otherwise>
                    <a href="${pageContext.request.contextPath}/login" class="auth-btn">
                        <i class="fa-regular fa-user"></i>
                        <span><fmt:message key="auth.register_login"/></span>
                    </a>
                </c:otherwise>
            </c:choose>
        </div>
    </div>
</div>

<header class="main-header">
    <div class="header-container">
        <a href="${pageContext.request.contextPath}/home" class="logo-area">
            <div class="logo-circle"><i class="fa-solid fa-paw logo-icon"></i></div>
            <div class="logo-text">
                <span class="logo-brand">Jolliebear</span>
                <span class="logo-slogan">I'm lovin' it</span>
            </div>
        </a>
        <nav class="navbar">
            <ul class="nav-menu">
                <li class="nav-item"><a href="${pageContext.request.contextPath}/home#home" class="nav-link"><fmt:message key="nav.home"/></a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/home#about" class="nav-link"><fmt:message key="nav.about"/></a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/home#menu" class="nav-link"><fmt:message key="nav.menu"/></a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/home#promotions" class="nav-link"><fmt:message key="nav.promotions"/></a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/home#services" class="nav-link"><fmt:message key="nav.services"/></a></li>
                <c:if test="${not empty sessionScope.authUser}">
                    <li class="nav-item"><a href="${pageContext.request.contextPath}/orders" class="nav-link"><fmt:message key="nav.orders"/></a></li>
                </c:if>
            </ul>
        </nav>
        <div class="header-actions">
            <a href="${pageContext.request.contextPath}/cart" class="cart-icon-btn" aria-label="Cart">
                <i class="fa-solid fa-cart-shopping"></i>
                <c:if test="${sessionScope.cart.totalQuantity > 0}">
                    <span class="cart-badge">${sessionScope.cart.totalQuantity}</span>
                </c:if>
            </a>
            <button class="mobile-nav-toggle" aria-label="Toggle navigation"><i class="fa-solid fa-bars"></i></button>
        </div>
    </div>
</header>
