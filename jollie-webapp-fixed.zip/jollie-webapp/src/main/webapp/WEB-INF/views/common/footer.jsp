<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<footer class="site-footer">
    <div class="footer-container">
        <div class="footer-top">
            <div class="footer-brand">
                <div class="footer-logo"><i class="fa-solid fa-paw"></i> Jolliebear</div>
                <p class="footer-desc"><fmt:message key="footer.desc"/></p>
                <div class="social-links">
                    <a href="#" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
                    <a href="#" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" aria-label="Youtube"><i class="fa-brands fa-youtube"></i></a>
                    <a href="#" aria-label="TikTok"><i class="fa-brands fa-tiktok"></i></a>
                </div>
            </div>
            <div class="footer-links-group">
                <h4><fmt:message key="footer.quick_links"/></h4>
                <ul>
                    <li><a href="${pageContext.request.contextPath}/home#about"><fmt:message key="nav.about"/></a></li>
                    <li><a href="${pageContext.request.contextPath}/home#promotions"><fmt:message key="nav.promotions"/></a></li>
                    <li><a href="${pageContext.request.contextPath}/home#services"><fmt:message key="nav.services"/></a></li>
                </ul>
            </div>
            <div class="footer-links-group">
                <h4><fmt:message key="footer.contact"/></h4>
                <ul>
                    <li><i class="fa-solid fa-phone"></i> Hotline: 1900 8080</li>
                    <li><i class="fa-solid fa-envelope"></i> Email: feedback@jolliebear.com.vn</li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p><fmt:message key="footer.copyright"/></p>
        </div>
    </div>
</footer>
