<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<fmt:setLocale value="${lang}" scope="request"/>
<fmt:setBundle basename="i18n.messages" scope="request"/>
<!DOCTYPE html>
<html lang="${lang}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jolliebear - <fmt:message key="auth.login_title"/></title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
    <jsp:include page="/WEB-INF/views/common/header.jsp"/>

    <section class="auth-section">
        <div class="auth-card">
            <div class="auth-card-icon"><i class="fa-solid fa-paw"></i></div>
            <h2><fmt:message key="auth.login_title"/></h2>
            <p class="auth-card-desc"><fmt:message key="auth.login_desc"/></p>

            <c:if test="${param.registered == '1'}">
                <div class="auth-alert auth-alert-success"><fmt:message key="auth.success_register"/></div>
            </c:if>
            <c:if test="${not empty errorKey}">
                <div class="auth-alert auth-alert-error"><fmt:message key="${errorKey}"/></div>
            </c:if>

            <form method="post" action="${pageContext.request.contextPath}/login" class="auth-form">
                <c:if test="${not empty param.redirect}">
                    <input type="hidden" name="redirect" value="${param.redirect}">
                </c:if>
                <label class="auth-label">
                    <fmt:message key="auth.email"/>
                    <input type="email" name="email" value="${email}" required autofocus>
                </label>
                <label class="auth-label">
                    <fmt:message key="auth.password"/>
                    <input type="password" name="password" required>
                </label>
                <button type="submit" class="btn btn-primary btn-block"><fmt:message key="auth.login_btn"/></button>
            </form>

            <p class="auth-switch">
                <fmt:message key="auth.no_account"/>
                <a href="${pageContext.request.contextPath}/register"><fmt:message key="auth.create_one"/></a>
            </p>
        </div>
    </section>

    <jsp:include page="/WEB-INF/views/common/footer.jsp"/>
    <script src="${pageContext.request.contextPath}/js/main.js"></script>
</body>
</html>
