<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<fmt:setLocale value="${lang}" scope="request"/>
<fmt:setBundle basename="i18n.messages" scope="request"/>
<!DOCTYPE html>
<html lang="${lang}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jolliebear - <c:out value="${empty item ? 'Món ăn' : item.getDisplayName(lang)}"/></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
    <jsp:include page="/WEB-INF/views/common/header.jsp"/>

    <section class="item-detail-section">
        <c:choose>
        <c:when test="${itemNotFound}">
            <div class="result-wrap">
                <i class="fa-solid fa-circle-exclamation"></i>
                <h2><fmt:message key="item.not_found"/></h2>
                <a href="${pageContext.request.contextPath}/home#menu" class="btn btn-primary"><fmt:message key="menu.back_to_menu"/></a>
            </div>
        </c:when>
        <c:otherwise>
            <div class="item-detail-container">
                <div class="item-detail-hero">
                    <div class="item-detail-icon"><i class="${item.iconClass}"></i></div>
                    <div>
                        <h2>${item.getDisplayName(lang)}</h2>
                        <p>${item.getDisplayDescription(lang)}</p>
                        <span class="item-detail-price"><fmt:formatNumber value="${item.basePrice}" type="number"/>đ</span>
                    </div>
                </div>

                <c:if test="${not empty errorKey}">
                    <div class="auth-alert auth-alert-error"><fmt:message key="${errorKey}"/></div>
                </c:if>

                <form method="post" action="${pageContext.request.contextPath}/item?id=${item.id}" class="item-options-form">

                    <c:forEach items="${item.optionGroups}" var="group">
                        <div class="option-group">
                            <h4>
                                ${group.getDisplayName(lang)}
                                <span class="option-group-tag">
                                    <fmt:message key="${group.required ? 'item.required' : 'item.optional'}"/>
                                </span>
                            </h4>
                            <div class="option-choice-list">
                                <c:forEach items="${group.choices}" var="choice" varStatus="st">
                                    <label class="option-choice">
                                        <input type="${group.multiSelect ? 'checkbox' : 'radio'}"
                                               name="group_${group.id}"
                                               value="${choice.id}"
                                               ${!group.multiSelect && (choice.default || st.first) ? 'checked' : ''}>
                                        <span class="option-choice-name">${choice.getDisplayName(lang)}</span>
                                        <c:if test="${choice.extraPrice > 0}">
                                            <span class="option-choice-price">+<fmt:formatNumber value="${choice.extraPrice}" type="number"/>đ</span>
                                        </c:if>
                                    </label>
                                </c:forEach>
                            </div>
                        </div>
                    </c:forEach>

                    <div class="option-group">
                        <h4><fmt:message key="item.note"/></h4>
                        <textarea name="note" rows="2" class="item-note-input"></textarea>
                    </div>

                    <div class="item-qty-row">
                        <label><fmt:message key="item.quantity"/></label>
                        <div class="qty-stepper">
                            <button type="button" class="qty-btn" data-step="-1">-</button>
                            <input type="number" name="quantity" id="qty-input" value="1" min="1" max="20">
                            <button type="button" class="qty-btn" data-step="1">+</button>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block btn-add-cart">
                        <fmt:message key="item.add_to_cart"/> <fmt:formatNumber value="${item.basePrice}" type="number"/>đ
                    </button>
                </form>
            </div>
        </c:otherwise>
        </c:choose>
    </section>

    <jsp:include page="/WEB-INF/views/common/footer.jsp"/>
    <script src="${pageContext.request.contextPath}/js/main.js"></script>
</body>
</html>
