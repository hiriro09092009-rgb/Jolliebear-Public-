<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<fmt:setLocale value="${lang}" scope="request"/>
<fmt:setBundle basename="i18n.messages" scope="request"/>
<!DOCTYPE html>
<html lang="${lang}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jolliebear - <fmt:message key="orders.title"/></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
    <jsp:include page="/WEB-INF/views/common/header.jsp"/>

    <section class="orders-section">
        <div class="orders-container">
            <h2><fmt:message key="orders.title"/></h2>

            <c:choose>
                <c:when test="${empty orders}">
                    <div class="cart-empty">
                        <i class="fa-solid fa-receipt"></i>
                        <p><fmt:message key="orders.empty"/></p>
                        <a href="${pageContext.request.contextPath}/home#menu" class="btn btn-primary"><fmt:message key="cart.continue_shopping"/></a>
                    </div>
                </c:when>
                <c:otherwise>
                    <c:forEach items="${orders}" var="o">
                        <div class="order-card">
                            <div class="order-card-header">
                                <div>
                                    <strong>#${o.orderCode}</strong>
                                    <span class="order-status status-${o.status}"><fmt:message key="orders.status.${o.status}"/></span>
                                </div>
                                <span class="order-date">
                                    <fmt:formatDate value="${o.createdAtAsDate}" pattern="dd/MM/yyyy HH:mm"/>
                                </span>
                            </div>
                            <div class="order-card-items">
                                <c:forEach items="${o.items}" var="oi">
                                    <div class="order-item-row">
                                        <span>${oi.quantity} x ${oi.itemName}</span>
                                        <span><fmt:formatNumber value="${oi.lineTotal}" type="number"/>đ</span>
                                    </div>
                                </c:forEach>
                            </div>
                            <div class="order-card-footer">
                                <span><fmt:message key="checkout.total"/></span>
                                <strong><fmt:formatNumber value="${o.total}" type="number"/>đ</strong>
                            </div>
                        </div>
                    </c:forEach>
                </c:otherwise>
            </c:choose>
        </div>
    </section>

    <jsp:include page="/WEB-INF/views/common/footer.jsp"/>
    <script src="${pageContext.request.contextPath}/js/main.js"></script>
</body>
</html>
