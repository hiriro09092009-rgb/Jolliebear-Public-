<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<fmt:setLocale value="${lang}" scope="request"/>
<fmt:setBundle basename="i18n.messages" scope="request"/>
<!DOCTYPE html>
<html lang="${lang}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jolliebear - 404</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
    <jsp:include page="/WEB-INF/views/common/header.jsp"/>
    <section class="result-section">
        <div class="result-wrap">
            <i class="fa-solid fa-triangle-exclamation"></i>
            <h2>404</h2>
            <p>${lang == 'en' ? 'Page not found.' : 'Không tìm thấy trang bạn yêu cầu.'}</p>
            <div class="result-actions">
                <a href="${pageContext.request.contextPath}/home" class="btn btn-primary">
                    <fmt:message key="confirm.back_home"/>
                </a>
            </div>
        </div>
    </section>
    <jsp:include page="/WEB-INF/views/common/footer.jsp"/>
</body>
</html>
