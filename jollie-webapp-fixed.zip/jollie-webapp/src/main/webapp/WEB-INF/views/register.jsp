<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<fmt:setLocale value="${lang}" scope="request"/>
<fmt:setBundle basename="i18n.messages" scope="request"/>
<!DOCTYPE html>
<html lang="${lang}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jolliebear - <fmt:message key="auth.register_title"/></title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
    <jsp:include page="/WEB-INF/views/common/header.jsp"/>

    <section class="auth-section">
        <div class="auth-card">
            <div class="auth-card-icon"><i class="fa-solid fa-paw"></i></div>
            <h2><fmt:message key="auth.register_title"/></h2>
            <p class="auth-card-desc"><fmt:message key="auth.register_desc"/></p>

            <c:if test="${not empty errorKey}">
                <div class="auth-alert auth-alert-error"><fmt:message key="${errorKey}"/></div>
            </c:if>
            <c:if test="${error == 'missing_fields'}">
                <div class="auth-alert auth-alert-error">
                    <c:choose>
                        <c:when test="${lang == 'en'}">Please fill in all required fields.</c:when>
                        <c:otherwise>Vui lòng điền đầy đủ thông tin bắt buộc.</c:otherwise>
                    </c:choose>
                </div>
            </c:if>

            <form method="post" action="${pageContext.request.contextPath}/register" class="auth-form">
                <label class="auth-label">
                    <fmt:message key="auth.fullname"/>
                    <input type="text" name="fullName" value="${fullName}" required autofocus>
                </label>
                <label class="auth-label">
                    <fmt:message key="auth.email"/>
                    <input type="email" name="email" value="${email}" required>
                </label>
                <label class="auth-label">
                    <fmt:message key="auth.phone"/>
                    <input type="tel" name="phone" value="${phone}" required>
                </label>
                <label class="auth-label">
                    <fmt:message key="auth.password"/>
                    <input type="password" name="password" minlength="6" required>
                </label>
                <label class="auth-label">
                    <fmt:message key="auth.confirm_password"/>
                    <input type="password" name="confirmPassword" minlength="6" required>
                </label>
                <button type="submit" class="btn btn-primary btn-block"><fmt:message key="auth.register_btn"/></button>
            </form>

            <p class="auth-switch">
                <fmt:message key="auth.have_account"/>
                <a href="${pageContext.request.contextPath}/login"><fmt:message key="auth.login_here"/></a>
            </p>
        </div>
    </section>

    <jsp:include page="/WEB-INF/views/common/footer.jsp"/>
    <script src="${pageContext.request.contextPath}/js/main.js"></script>
</body>
</html>
