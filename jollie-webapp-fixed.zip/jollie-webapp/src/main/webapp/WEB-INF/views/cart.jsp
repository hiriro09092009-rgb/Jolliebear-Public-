<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<fmt:setLocale value="${lang}" scope="request"/>
<fmt:setBundle basename="i18n.messages" scope="request"/>
<!DOCTYPE html>
<html lang="${lang}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jolliebear - <fmt:message key="cart.title"/></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
    <jsp:include page="/WEB-INF/views/common/header.jsp"/>

    <section class="cart-section">
        <div class="cart-container">
            <h2><fmt:message key="cart.title"/></h2>

            <c:choose>
                <c:when test="${empty cart.lines}">
                    <div class="cart-empty">
                        <i class="fa-solid fa-cart-shopping"></i>
                        <p><fmt:message key="cart.empty"/></p>
                        <a href="${pageContext.request.contextPath}/home#menu" class="btn btn-primary"><fmt:message key="cart.continue_shopping"/></a>
                    </div>
                </c:when>
                <c:otherwise>
                    <div class="cart-lines">
                        <c:forEach items="${cart.lines}" var="line">
                            <div class="cart-line">
                                <div class="cart-line-icon"><i class="${line.iconClass}"></i></div>
                                <div class="cart-line-info">
                                    <h4>${line.itemName}</h4>
                                    <c:if test="${not empty line.optionsSummary}"><p class="cart-line-options">${line.optionsSummary}</p></c:if>
                                    <c:if test="${not empty line.note}"><p class="cart-line-note">"${line.note}"</p></c:if>
                                    <span class="cart-line-unit-price"><fmt:formatNumber value="${line.unitPrice}" type="number"/>đ / <fmt:message key="item.quantity"/></span>
                                </div>
                                <form method="post" action="${pageContext.request.contextPath}/cart" class="cart-line-qty-form">
                                    <input type="hidden" name="action" value="update">
                                    <input type="hidden" name="lineId" value="${line.lineId}">
                                    <input type="number" name="quantity" value="${line.quantity}" min="1" max="20" class="cart-qty-input"
                                           onchange="this.form.submit()">
                                </form>
                                <div class="cart-line-total"><fmt:formatNumber value="${line.lineTotal}" type="number"/>đ</div>
                                <form method="post" action="${pageContext.request.contextPath}/cart">
                                    <input type="hidden" name="action" value="remove">
                                    <input type="hidden" name="lineId" value="${line.lineId}">
                                    <button type="submit" class="cart-remove-btn" aria-label="Remove"><i class="fa-solid fa-trash"></i></button>
                                </form>
                            </div>
                        </c:forEach>
                    </div>

                    <div class="cart-summary">
                        <div class="cart-summary-row">
                            <span><fmt:message key="cart.subtotal"/></span>
                            <strong><fmt:formatNumber value="${cart.subtotal}" type="number"/>đ</strong>
                        </div>
                        <a href="${pageContext.request.contextPath}/checkout" class="btn btn-primary btn-block"><fmt:message key="cart.checkout"/></a>
                        <a href="${pageContext.request.contextPath}/home#menu" class="cart-continue-link"><fmt:message key="cart.continue_shopping"/></a>
                    </div>
                </c:otherwise>
            </c:choose>
        </div>
    </section>

    <jsp:include page="/WEB-INF/views/common/footer.jsp"/>
    <script src="${pageContext.request.contextPath}/js/main.js"></script>
</body>
</html>
