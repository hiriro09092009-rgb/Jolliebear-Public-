<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<fmt:setLocale value="${lang}" scope="request"/>
<fmt:setBundle basename="i18n.messages" scope="request"/>
<!DOCTYPE html>
<html lang="${lang}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jolliebear - <fmt:message key="confirm.title"/></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
    <jsp:include page="/WEB-INF/views/common/header.jsp"/>

    <section class="result-section">
        <div class="result-wrap">
            <i class="fa-solid fa-circle-check" style="color:#2ecc71;"></i>
            <h2><fmt:message key="confirm.title"/></h2>
            <p><fmt:message key="confirm.desc"/></p>
            <c:if test="${not empty order}">
                <p class="order-code-badge"><fmt:message key="confirm.order_code"/>: <strong>${order.orderCode}</strong></p>
                <p class="order-total-badge"><fmt:message key="checkout.total"/>: <strong><fmt:formatNumber value="${order.total}" type="number"/>đ</strong></p>
            </c:if>
            <div class="result-actions">
                <a href="${pageContext.request.contextPath}/orders" class="btn btn-primary"><fmt:message key="confirm.view_orders"/></a>
                <a href="${pageContext.request.contextPath}/home" class="btn btn-outline"><fmt:message key="confirm.back_home"/></a>
            </div>
        </div>
    </section>

    <jsp:include page="/WEB-INF/views/common/footer.jsp"/>
    <script src="${pageContext.request.contextPath}/js/main.js"></script>
</body>
</html>
