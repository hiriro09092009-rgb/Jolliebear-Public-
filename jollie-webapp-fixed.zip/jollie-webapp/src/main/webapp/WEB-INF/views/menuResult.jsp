<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<fmt:setLocale value="${lang}" scope="request"/>
<fmt:setBundle basename="i18n.messages" scope="request"/>
<!DOCTYPE html>
<html lang="${lang}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jolliebear - <c:out value="${empty category ? 'Thực đơn' : category.getDisplayTitle(lang)}"/></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
    <jsp:include page="/WEB-INF/views/common/header.jsp"/>

    <section class="menu-list-section">
        <div class="menu-list-container">
            <a href="${pageContext.request.contextPath}/home#menu" class="back-link">
                <i class="fa-solid fa-arrow-left"></i> <fmt:message key="menu.back_to_menu"/>
            </a>

            <div class="section-heading">
                <h2>
                    <c:choose>
                        <c:when test="${not empty category}">${category.getDisplayTitle(lang)}</c:when>
                        <c:otherwise><fmt:message key="menu.section_title"/></c:otherwise>
                    </c:choose>
                </h2>
                <c:if test="${not empty category}"><p>${category.getDisplayDescription(lang)}</p></c:if>
            </div>

            <div class="dish-grid">
                <c:forEach items="${items}" var="dish">
                    <div class="dish-card">
                        <c:if test="${dish.bestSeller}"><span class="dish-badge"><fmt:message key="menu.best_seller"/></span></c:if>
                        <div class="dish-icon-wrap"><i class="${dish.iconClass}"></i></div>
                        <div class="dish-info">
                            <h3>${dish.getDisplayName(lang)}</h3>
                            <p>${dish.getDisplayDescription(lang)}</p>
                            <div class="dish-price-row">
                                <span class="dish-price"><fmt:formatNumber value="${dish.basePrice}" type="number"/>đ</span>
                                <a href="${pageContext.request.contextPath}/item?id=${dish.id}" class="btn btn-primary btn-sm">
                                    <fmt:message key="menu.customize"/>
                                </a>
                            </div>
                        </div>
                    </div>
                </c:forEach>

                <c:if test="${empty items}">
                    <p><fmt:message key="menu.empty"/></p>
                </c:if>
            </div>
        </div>
    </section>

    <jsp:include page="/WEB-INF/views/common/footer.jsp"/>
    <script src="${pageContext.request.contextPath}/js/main.js"></script>
</body>
</html>
