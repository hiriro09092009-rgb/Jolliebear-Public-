<%@ page contentType="text/html;charset=UTF-8" language="java" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<fmt:setLocale value="${lang}" scope="request"/>
<fmt:setBundle basename="i18n.messages" scope="request"/>
<!DOCTYPE html>
<html lang="${lang}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jolliebear - Giao Hàng Tận Nơi &amp; Thực Đơn Thơm Ngon</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

    <jsp:include page="/WEB-INF/views/common/header.jsp"/>

    <!-- HERO (giữ nguyên tĩnh) -->
    <section class="hero-carousel" id="home">
        <div class="carousel-track-container">
            <ul class="carousel-track">
                <li class="carousel-slide current-slide">
                    <div class="slide-content bg-gradient-1">
                        <div class="slide-inner">
                            <div class="slide-text">
                                <span class="badge"><fmt:message key="hero.badge"/></span>
                                <h2><fmt:message key="hero.title"/></h2>
                                <p><fmt:message key="hero.desc"/></p>
                                <div class="price-tag"><span class="price">35.000đ</span> <span class="unit">/ Phần</span></div>
                                <a href="#menu" class="btn btn-primary"><fmt:message key="hero.order_now"/> <i class="fa-solid fa-arrow-right"></i></a>
                            </div>
                            <div class="slide-graphic">
                                <div class="food-plate chicken-plate">
                                    <span class="graphic-shadow"></span>
                                    <i class="fa-solid fa-drumstick-bite graphic-food-icon animate-float"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <div class="carousel-nav">
            <button class="carousel-indicator current-slide-indicator" aria-label="Slide 1"></button>
        </div>
    </section>

    <!-- ĐẶT HÀNG: GIAO TẬN NƠI / ĐẾN LẤY -->
    <section class="order-section">
        <div class="order-container">
            <div class="order-toggle-wrapper">
                <button class="toggle-btn active" id="delivery-toggle">
                    <i class="fa-solid fa-motorcycle"></i> <fmt:message key="order.delivery"/>
                </button>
                <button class="toggle-btn" id="pickup-toggle">
                    <i class="fa-solid fa-store"></i> <fmt:message key="order.pickup"/>
                </button>
            </div>
            <div class="address-search-box">
                <div class="input-wrapper">
                    <i class="fa-solid fa-location-dot input-loc-icon"></i>
                    <input type="text" id="address-input"
                           placeholder="<fmt:message key='order.address_placeholder'/>"
                           data-placeholder-delivery="<fmt:message key='order.address_placeholder'/>"
                           data-placeholder-pickup="<fmt:message key='order.pickup_placeholder'/>"
                           aria-label="Address">
                    <button class="search-btn" aria-label="Search"><i class="fa-solid fa-magnifying-glass"></i></button>
                </div>
            </div>
        </div>
    </section>

    <!-- "ĂN GÌ HÔM NAY" - DỮ LIỆU ĐỘNG TỪ SERVLET (request scope: menuCategories) -->
    <section class="featured-section" id="menu">
        <div class="featured-container">
            <div class="promo-brand-card">
                <div class="promo-content">
                    <div class="brand-mascot-wrapper"><i class="fa-solid fa-paw mascot-icon"></i></div>
                    <h2><fmt:message key="menu.section_title"/></h2>
                    <p><fmt:message key="menu.section_desc"/></p>
                </div>
            </div>

            <div class="category-cards-grid">
                <c:forEach items="${menuCategories}" var="m">
                    <div class="category-card wood-card">
                        <div class="card-image-wrapper">
                            <div class="food-mock-img ${m.bgClass}">
                                <i class="${m.iconClass} food-mock-icon"></i>
                            </div>
                        </div>
                        <div class="card-info">
                            <h3>${m.getDisplayTitle(lang)}</h3>
                            <p>${m.getDisplayDescription(lang)}</p>
                            <a href="${pageContext.request.contextPath}/${m.link}" class="card-link">
                                <fmt:message key="menu.view"/> <i class="fa-solid fa-chevron-right"></i>
                            </a>
                        </div>
                    </div>
                </c:forEach>

                <c:if test="${empty menuCategories}">
                    <p><fmt:message key="menu.empty"/></p>
                </c:if>
            </div>
        </div>
    </section>

    <!-- KHUYẾN MÃI - DỮ LIỆU ĐỘNG TỪ SERVLET (request scope: promotions) -->
    <section class="promo-section" id="promotions">
        <div class="promo-section-container">
            <div class="section-heading">
                <span class="section-tag"><fmt:message key="promo.section_tag"/></span>
                <h2><fmt:message key="promo.section_title"/></h2>
                <p><fmt:message key="promo.section_desc"/></p>
            </div>

            <div class="promo-countdown-banner">
                <div class="countdown-left">
                    <i class="fa-solid fa-bolt countdown-icon"></i>
                    <div>
                        <h3><fmt:message key="promo.flash_sale"/></h3>
                        <p><fmt:message key="promo.flash_desc"/></p>
                    </div>
                </div>
                <div class="countdown-timer" id="promo-countdown">
                    <div class="time-box"><span id="cd-hours">00</span><small><fmt:message key="promo.hours"/></small></div>
                    <div class="time-box"><span id="cd-minutes">00</span><small><fmt:message key="promo.minutes"/></small></div>
                    <div class="time-box"><span id="cd-seconds">00</span><small><fmt:message key="promo.seconds"/></small></div>
                </div>
            </div>

            <div class="promo-cards-grid">
                <c:forEach items="${promotions}" var="p">
                    <div class="promo-card">
                        <div class="promo-discount-badge">${p.badgeText}</div>
                        <div class="promo-card-icon ${p.iconBgClass}">
                            <i class="${p.iconClass}"></i>
                        </div>
                        <div class="promo-card-body">
                            <span class="promo-label">${p.getDisplayLabel(lang)}</span>
                            <h3>${p.getDisplayTitle(lang)}</h3>
                            <p>${p.getDisplayDescription(lang)}</p>
                            <div class="promo-price-row">
                                <span class="promo-price-new">${p.priceNew}</span>
                                <c:if test="${not empty p.priceOld}">
                                    <span class="promo-price-old">${p.priceOld}</span>
                                </c:if>
                            </div>
                            <a href="${pageContext.request.contextPath}/${p.buttonLink}" class="btn btn-primary btn-block">${p.getDisplayButtonText(lang)}</a>
                        </div>
                    </div>
                </c:forEach>

                <c:if test="${empty promotions}">
                    <p><fmt:message key="promo.empty"/></p>
                </c:if>
            </div>
        </div>
    </section>

    <!-- DỊCH VỤ - DỮ LIỆU ĐỘNG TỪ SERVLET (request scope: services) -->
    <section class="services-section" id="services">
        <div class="services-container">
            <div class="section-heading light-heading">
                <span class="section-tag"><fmt:message key="services.section_tag"/></span>
                <h2><fmt:message key="services.section_title"/></h2>
                <p><fmt:message key="services.section_desc"/></p>
            </div>

            <div class="services-grid">
                <c:forEach items="${services}" var="s">
                    <div class="service-card">
                        <div class="service-icon-wrap"><i class="${s.iconClass}"></i></div>
                        <h3>${s.getDisplayTitle(lang)}</h3>
                        <p>${s.getDisplayDescription(lang)}</p>
                        <a href="${pageContext.request.contextPath}/${s.link}" class="service-link">
                            ${s.getDisplayLinkText(lang)} <i class="fa-solid fa-arrow-right"></i>
                        </a>
                    </div>
                </c:forEach>

                <c:if test="${empty services}">
                    <p><fmt:message key="services.empty"/></p>
                </c:if>
            </div>
        </div>
    </section>

    <jsp:include page="/WEB-INF/views/common/footer.jsp"/>

    <script src="${pageContext.request.contextPath}/js/main.js"></script>
</body>
</html>
