-- ============================================================================
-- Jolliebear - Script khởi tạo Database ĐẦY ĐỦ cho SQL Server
-- ============================================================================
-- Script này tạo toàn bộ database + TẤT CẢ bảng + dữ liệu mẫu cho MỌI tính năng:
--   - users (kèm 1 tài khoản demo đăng nhập được sẵn)
--   - menu_categories, menu_items, option_groups, option_choices
--   - promotions, services
--   - orders, order_items, order_item_options (kèm 2 đơn hàng demo)
--
-- CÁCH DÙNG:
--   1. Mở SSMS (hoặc Data Source Explorer trong Eclipse) bằng tài khoản có
--      quyền tạo database (VD: sa).
--   2. Chạy TOÀN BỘ file này 1 lần duy nhất.
--   3. Hibernate (hibernate.hbm2ddl.auto=update) khi ứng dụng chạy sẽ nhận ra
--      các bảng đã tồn tại và sẽ KHÔNG seed lại (vì bảng đã có dữ liệu), giữ
--      nguyên toàn bộ dữ liệu đầy đủ mà script này đã tạo sẵn.
--
-- Nếu bạn ĐÃ CHẠY BẢN CŨ trước đây (bị lỗi hiển thị dấu "?" do cột VARCHAR):
--   DROP DATABASE JollieBearDB;
--   GO
-- rồi chạy lại toàn bộ script này từ đầu.
--
-- TÀI KHOẢN DEMO ĐỂ ĐĂNG NHẬP THỬ NGAY:
--   Email:    demo@jolliebear.vn
--   Mật khẩu: Jolliebear123
-- (mật khẩu đã được băm sẵn bằng PBKDF2WithHmacSHA256 + salt, đúng thuật toán
--  trong com.jolliebear.util.PasswordUtil, nên đăng nhập qua ứng dụng sẽ hoạt động)
-- ============================================================================

IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'JollieBearDB')
BEGIN
    CREATE DATABASE JollieBearDB;
END
GO

-- Đảm bảo tài khoản 'sa' đã bật (mặc định SQL Server Authentication):
-- 1. Mở SSMS -> Security -> Logins -> sa -> Properties
--    -> General: đặt mật khẩu = 12345678 (khớp với persistence.xml)
--    -> Status: Login = Enabled
-- 2. Server Properties -> Security -> chọn "SQL Server and Windows Authentication mode"
-- 3. Restart dịch vụ SQL Server sau khi đổi Authentication mode.

USE JollieBearDB;
GO

-- ============================================================================
-- XOÁ BẢNG CŨ (nếu có) THEO ĐÚNG THỨ TỰ FOREIGN KEY, để chạy lại script nhiều
-- lần không bị lỗi "object already exists".
-- ============================================================================
IF OBJECT_ID('dbo.order_item_options', 'U') IS NOT NULL DROP TABLE dbo.order_item_options;
IF OBJECT_ID('dbo.order_items', 'U') IS NOT NULL DROP TABLE dbo.order_items;
IF OBJECT_ID('dbo.orders', 'U') IS NOT NULL DROP TABLE dbo.orders;
IF OBJECT_ID('dbo.option_choices', 'U') IS NOT NULL DROP TABLE dbo.option_choices;
IF OBJECT_ID('dbo.option_groups', 'U') IS NOT NULL DROP TABLE dbo.option_groups;
IF OBJECT_ID('dbo.menu_items', 'U') IS NOT NULL DROP TABLE dbo.menu_items;
IF OBJECT_ID('dbo.menu_categories', 'U') IS NOT NULL DROP TABLE dbo.menu_categories;
IF OBJECT_ID('dbo.promotions', 'U') IS NOT NULL DROP TABLE dbo.promotions;
IF OBJECT_ID('dbo.services', 'U') IS NOT NULL DROP TABLE dbo.services;
IF OBJECT_ID('dbo.users', 'U') IS NOT NULL DROP TABLE dbo.users;
GO

-- ============================================================================
-- BẢNG: users
-- ============================================================================
CREATE TABLE dbo.users (
    id             INT IDENTITY(1,1) PRIMARY KEY,
    fullName       NVARCHAR(150)  NOT NULL,
    email          VARCHAR(150)   NOT NULL,
    phone          VARCHAR(20)    NOT NULL,
    passwordHash   VARCHAR(255)   NOT NULL,
    passwordSalt   VARCHAR(64)    NOT NULL,
    defaultAddress NVARCHAR(500)  NULL,
    createdAt      DATETIME2      NULL,
    CONSTRAINT uk_users_email UNIQUE (email)
);
GO

-- ============================================================================
-- BẢNG: menu_categories
-- ============================================================================
CREATE TABLE dbo.menu_categories (
    id            INT IDENTITY(1,1) PRIMARY KEY,
    iconClass     VARCHAR(255)    NULL,
    bgClass       VARCHAR(255)    NULL,
    title         NVARCHAR(300)   NULL,
    titleEn       NVARCHAR(300)   NULL,
    description   NVARCHAR(1000)  NULL,
    descriptionEn NVARCHAR(1000)  NULL,
    link          VARCHAR(255)    NULL
);
GO

-- ============================================================================
-- BẢNG: menu_items
-- ============================================================================
CREATE TABLE dbo.menu_items (
    id            INT IDENTITY(1,1) PRIMARY KEY,
    category_id   INT             NULL,
    name          NVARCHAR(300)   NOT NULL,
    nameEn        NVARCHAR(300)   NULL,
    description   NVARCHAR(1000)  NULL,
    descriptionEn NVARCHAR(1000)  NULL,
    basePrice     DECIMAL(12,0)   NOT NULL,
    iconClass     VARCHAR(255)    NULL,
    available     BIT             NOT NULL DEFAULT 1,
    bestSeller    BIT             NOT NULL DEFAULT 0,
    CONSTRAINT fk_menu_items_category FOREIGN KEY (category_id) REFERENCES dbo.menu_categories(id)
);
GO

-- ============================================================================
-- BẢNG: option_groups (VD: "Chọn size", "Độ cay", "Món thêm")
-- ============================================================================
CREATE TABLE dbo.option_groups (
    id            INT IDENTITY(1,1) PRIMARY KEY,
    menu_item_id  INT             NULL,
    name          NVARCHAR(200)   NOT NULL,
    nameEn        NVARCHAR(200)   NULL,
    required      BIT             NOT NULL DEFAULT 0,
    multiSelect   BIT             NOT NULL DEFAULT 0,
    displayOrder  INT             NOT NULL DEFAULT 0,
    CONSTRAINT fk_option_groups_item FOREIGN KEY (menu_item_id) REFERENCES dbo.menu_items(id)
);
GO

-- ============================================================================
-- BẢNG: option_choices (VD: "1 Miếng", "Cay vừa", "Thêm phô mai (+8.000đ)")
-- ============================================================================
CREATE TABLE dbo.option_choices (
    id              INT IDENTITY(1,1) PRIMARY KEY,
    option_group_id INT             NULL,
    name            NVARCHAR(200)   NOT NULL,
    nameEn          NVARCHAR(200)   NULL,
    extraPrice      DECIMAL(12,0)   NOT NULL DEFAULT 0,
    isDefault       BIT             NOT NULL DEFAULT 0,
    CONSTRAINT fk_option_choices_group FOREIGN KEY (option_group_id) REFERENCES dbo.option_groups(id)
);
GO

-- ============================================================================
-- BẢNG: promotions
-- ============================================================================
CREATE TABLE dbo.promotions (
    id            INT IDENTITY(1,1) PRIMARY KEY,
    badgeText     NVARCHAR(50)    NULL,
    label         NVARCHAR(100)   NULL,
    labelEn       NVARCHAR(100)   NULL,
    title         NVARCHAR(300)   NULL,
    titleEn       NVARCHAR(300)   NULL,
    description   NVARCHAR(1000)  NULL,
    descriptionEn NVARCHAR(1000)  NULL,
    priceNew      NVARCHAR(50)    NULL,
    priceOld      NVARCHAR(50)    NULL,
    iconClass     VARCHAR(255)    NULL,
    iconBgClass   VARCHAR(255)    NULL,
    buttonText    NVARCHAR(100)   NULL,
    buttonTextEn  NVARCHAR(100)   NULL,
    buttonLink    VARCHAR(255)    NULL
);
GO

-- ============================================================================
-- BẢNG: services
-- ============================================================================
CREATE TABLE dbo.services (
    id            INT IDENTITY(1,1) PRIMARY KEY,
    iconClass     VARCHAR(255)    NULL,
    title         NVARCHAR(300)   NULL,
    titleEn       NVARCHAR(300)   NULL,
    description   NVARCHAR(1000)  NULL,
    descriptionEn NVARCHAR(1000)  NULL,
    linkText      NVARCHAR(100)   NULL,
    linkTextEn    NVARCHAR(100)   NULL,
    link          VARCHAR(255)    NULL
);
GO

-- ============================================================================
-- BẢNG: orders
-- ============================================================================
CREATE TABLE dbo.orders (
    id              INT IDENTITY(1,1) PRIMARY KEY,
    orderCode       VARCHAR(20)     NOT NULL,
    user_id         INT             NOT NULL,
    orderType       VARCHAR(20)     NOT NULL,
    status          VARCHAR(20)     NOT NULL DEFAULT 'PENDING',
    deliveryAddress NVARCHAR(500)   NULL,
    contactPhone    VARCHAR(20)     NULL,
    note            NVARCHAR(500)   NULL,
    subtotal        DECIMAL(12,0)   NOT NULL,
    shippingFee     DECIMAL(12,0)   NOT NULL DEFAULT 0,
    total           DECIMAL(12,0)   NOT NULL,
    createdAt       DATETIME2       NULL,
    CONSTRAINT uk_orders_code UNIQUE (orderCode),
    CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES dbo.users(id)
);
GO

-- ============================================================================
-- BẢNG: order_items (snapshot tên món + đơn giá tại thời điểm đặt)
-- ============================================================================
CREATE TABLE dbo.order_items (
    id            INT IDENTITY(1,1) PRIMARY KEY,
    order_id      INT             NULL,
    menu_item_id  INT             NULL,
    itemName      NVARCHAR(300)   NOT NULL,
    unitPrice     DECIMAL(12,0)   NOT NULL,
    quantity      INT             NOT NULL,
    lineTotal     DECIMAL(12,0)   NOT NULL,
    note          NVARCHAR(300)   NULL,
    CONSTRAINT fk_order_items_order FOREIGN KEY (order_id) REFERENCES dbo.orders(id),
    CONSTRAINT fk_order_items_menuitem FOREIGN KEY (menu_item_id) REFERENCES dbo.menu_items(id)
);
GO

-- ============================================================================
-- BẢNG: order_item_options (snapshot tuỳ chọn đã chọn, VD "Size: L (+10.000đ)")
-- ============================================================================
CREATE TABLE dbo.order_item_options (
    id              INT IDENTITY(1,1) PRIMARY KEY,
    order_item_id   INT             NULL,
    groupName       NVARCHAR(200)   NOT NULL,
    choiceName      NVARCHAR(200)   NOT NULL,
    extraPrice      DECIMAL(12,0)   NOT NULL DEFAULT 0,
    CONSTRAINT fk_order_item_options_item FOREIGN KEY (order_item_id) REFERENCES dbo.order_items(id)
);
GO

-- ============================================================================
-- DỮ LIỆU MẪU: users (1 tài khoản demo đăng nhập được ngay)
-- Email: demo@jolliebear.vn | Mật khẩu: Jolliebear123
-- ============================================================================
INSERT INTO dbo.users (fullName, email, phone, passwordHash, passwordSalt, defaultAddress, createdAt) VALUES
(N'Nguyễn Văn Demo', 'demo@jolliebear.vn', '0901234567',
 's7G6j9lVN8ZeAd9Vhwh7LF2Dc7AhqlJjBQOwB5Qh/LQ=', 'C3OssejYCMeei2au69zSbg==',
 N'123 Đường Nguyễn Huệ, Quận 1, TP.HCM', SYSDATETIME());
GO

-- ============================================================================
-- DỮ LIỆU MẪU: menu_categories (4 danh mục - giống seedDefaultData trong Java)
-- ============================================================================
INSERT INTO dbo.menu_categories (iconClass, bgClass, title, titleEn, description, descriptionEn, link) VALUES
('fa-solid fa-drumstick-bite', 'chicken-mock', N'Gà Giòn Vui Vẻ', 'Crispy Fried Chicken',
 N'Thơm giòn rụm bên ngoài, mọng nước bên trong.', 'Crispy on the outside, juicy on the inside.', 'menu?cat=chicken'),
('fa-solid fa-fire-flame-curved', 'spicy-mock', N'Gà Sốt Cay & Ngọt', 'Spicy & Sweet Chicken',
 N'Sốt đặc trưng thấm sâu cay tê kích thích vị giác.', 'Signature sauce, spicy-sweet and packed with flavor.', 'menu?cat=spicy'),
('fa-solid fa-bowl-food', 'spaghetti-mock', N'Mỳ Ý Sốt Bò Bằm', 'Spaghetti Bolognese',
 N'Mỳ dai mềm kết hợp sốt thịt băm đậm đà.', 'Chewy pasta with rich minced beef sauce.', 'menu?cat=spaghetti'),
('fa-solid fa-ice-cream', 'dessert-mock', N'Tráng Miệng Ngọt Ngào', 'Sweet Desserts',
 N'Kem tươi mát lạnh, giải nhiệt ngày hè.', 'Cool, creamy desserts to beat the heat.', 'menu?cat=dessert');
GO

-- ============================================================================
-- DỮ LIỆU MẪU: menu_items (8 món - 2 món / danh mục, giống seedDefaultData trong Java)
-- ============================================================================
DECLARE @catChicken INT = (SELECT id FROM dbo.menu_categories WHERE link = 'menu?cat=chicken');
DECLARE @catSpicy INT = (SELECT id FROM dbo.menu_categories WHERE link = 'menu?cat=spicy');
DECLARE @catSpaghetti INT = (SELECT id FROM dbo.menu_categories WHERE link = 'menu?cat=spaghetti');
DECLARE @catDessert INT = (SELECT id FROM dbo.menu_categories WHERE link = 'menu?cat=dessert');

INSERT INTO dbo.menu_items (category_id, name, nameEn, description, descriptionEn, basePrice, iconClass, available, bestSeller) VALUES
(@catChicken, N'Gà Giòn Truyền Thống', 'Classic Crispy Chicken',
  N'Gà tẩm bột giòn rụm chiên vàng, công thức bí truyền Jolliebear.',
  'Crispy battered chicken deep-fried golden, Jolliebear''s secret recipe.', 35000, 'fa-solid fa-drumstick-bite', 1, 1),
(@catChicken, N'Gà Giòn Sốt Phô Mai', 'Cheese Sauce Crispy Chicken',
  N'Gà giòn phủ sốt phô mai béo ngậy tan chảy.',
  'Crispy chicken topped with rich melted cheese sauce.', 45000, 'fa-solid fa-drumstick-bite', 1, 0),
(@catSpicy, N'Gà Sốt Cay Hàn Quốc', 'Korean Spicy Chicken',
  N'Gà chiên giòn áo sốt cay ngọt kiểu Hàn Quốc.',
  'Crispy fried chicken glazed in Korean sweet & spicy sauce.', 42000, 'fa-solid fa-pepper-hot', 1, 1),
(@catSpicy, N'Cánh Gà Sốt Cay', 'Spicy Chicken Wings',
  N'Cánh gà chiên giòn, sốt cay đậm đà.',
  'Deep-fried chicken wings tossed in bold spicy sauce.', 38000, 'fa-solid fa-fire-flame-curved', 1, 0),
(@catSpaghetti, N'Mỳ Ý Sốt Bò Bằm', 'Spaghetti Bolognese',
  N'Mỳ Ý sốt thịt bò bằm đậm đà, phô mai bào phủ trên.',
  'Spaghetti with rich minced beef sauce, topped with grated cheese.', 39000, 'fa-solid fa-bowl-food', 1, 1),
(@catSpaghetti, N'Mỳ Ý Sốt Kem Nấm', 'Creamy Mushroom Spaghetti',
  N'Mỳ Ý sốt kem nấm béo mịn, thơm bơ tỏi.',
  'Spaghetti in creamy mushroom sauce with garlic butter aroma.', 39000, 'fa-solid fa-bowl-food', 1, 0),
(@catDessert, N'Kem Ốc Quế Vani', 'Vanilla Soft Cone',
  N'Kem vani mềm mịn, mát lạnh giải nhiệt.',
  'Soft, creamy vanilla ice cream cone.', 15000, 'fa-solid fa-ice-cream', 1, 0),
(@catDessert, N'Bánh Trứng Nướng', 'Baked Egg Tart',
  N'Bánh trứng nướng vỏ giòn, nhân béo thơm.',
  'Crispy egg tart with a rich, fragrant custard filling.', 18000, 'fa-solid fa-cookie', 1, 0);
GO

-- ============================================================================
-- DỮ LIỆU MẪU: option_groups + option_choices cho từng món (giống logic Java)
-- ============================================================================

-- ----- Gà Giòn Truyền Thống -----
DECLARE @item1 INT = (SELECT id FROM dbo.menu_items WHERE name = N'Gà Giòn Truyền Thống');
DECLARE @g1 INT, @g2 INT, @g3 INT;

INSERT INTO dbo.option_groups (menu_item_id, name, nameEn, required, multiSelect, displayOrder) VALUES
(@item1, N'Chọn số lượng', 'Choose quantity', 1, 0, 1);
SET @g1 = SCOPE_IDENTITY();
INSERT INTO dbo.option_choices (option_group_id, name, nameEn, extraPrice, isDefault) VALUES
(@g1, N'1 Miếng', '1 Piece', 0, 1),
(@g1, N'2 Miếng', '2 Pieces', 30000, 0),
(@g1, N'3 Miếng', '3 Pieces', 58000, 0);

INSERT INTO dbo.option_groups (menu_item_id, name, nameEn, required, multiSelect, displayOrder) VALUES
(@item1, N'Độ cay', 'Spice level', 1, 0, 2);
SET @g2 = SCOPE_IDENTITY();
INSERT INTO dbo.option_choices (option_group_id, name, nameEn, extraPrice, isDefault) VALUES
(@g2, N'Không cay', 'Not spicy', 0, 1),
(@g2, N'Cay vừa', 'Medium spicy', 0, 0),
(@g2, N'Cay nhiều', 'Extra spicy', 0, 0);

INSERT INTO dbo.option_groups (menu_item_id, name, nameEn, required, multiSelect, displayOrder) VALUES
(@item1, N'Món thêm', 'Add-ons', 0, 1, 3);
SET @g3 = SCOPE_IDENTITY();
INSERT INTO dbo.option_choices (option_group_id, name, nameEn, extraPrice, isDefault) VALUES
(@g3, N'Khoai tây chiên', 'French fries', 15000, 0),
(@g3, N'Nước ngọt size vừa', 'Medium soft drink', 10000, 0),
(@g3, N'Cơm trắng', 'Steamed rice', 8000, 0);

-- ----- Gà Giòn Sốt Phô Mai -----
DECLARE @item2 INT = (SELECT id FROM dbo.menu_items WHERE name = N'Gà Giòn Sốt Phô Mai');
DECLARE @g4 INT, @g5 INT, @g6 INT;

INSERT INTO dbo.option_groups (menu_item_id, name, nameEn, required, multiSelect, displayOrder) VALUES
(@item2, N'Chọn số lượng', 'Choose quantity', 1, 0, 1);
SET @g4 = SCOPE_IDENTITY();
INSERT INTO dbo.option_choices (option_group_id, name, nameEn, extraPrice, isDefault) VALUES
(@g4, N'1 Miếng', '1 Piece', 0, 1),
(@g4, N'2 Miếng', '2 Pieces', 30000, 0),
(@g4, N'3 Miếng', '3 Pieces', 58000, 0);

INSERT INTO dbo.option_groups (menu_item_id, name, nameEn, required, multiSelect, displayOrder) VALUES
(@item2, N'Độ cay', 'Spice level', 1, 0, 2);
SET @g5 = SCOPE_IDENTITY();
INSERT INTO dbo.option_choices (option_group_id, name, nameEn, extraPrice, isDefault) VALUES
(@g5, N'Không cay', 'Not spicy', 0, 1),
(@g5, N'Cay vừa', 'Medium spicy', 0, 0),
(@g5, N'Cay nhiều', 'Extra spicy', 0, 0);

INSERT INTO dbo.option_groups (menu_item_id, name, nameEn, required, multiSelect, displayOrder) VALUES
(@item2, N'Món thêm', 'Add-ons', 0, 1, 3);
SET @g6 = SCOPE_IDENTITY();
INSERT INTO dbo.option_choices (option_group_id, name, nameEn, extraPrice, isDefault) VALUES
(@g6, N'Khoai tây chiên', 'French fries', 15000, 0),
(@g6, N'Nước ngọt size vừa', 'Medium soft drink', 10000, 0),
(@g6, N'Cơm trắng', 'Steamed rice', 8000, 0);

-- ----- Gà Sốt Cay Hàn Quốc -----
DECLARE @item3 INT = (SELECT id FROM dbo.menu_items WHERE name = N'Gà Sốt Cay Hàn Quốc');
DECLARE @g7 INT, @g8 INT;

INSERT INTO dbo.option_groups (menu_item_id, name, nameEn, required, multiSelect, displayOrder) VALUES
(@item3, N'Độ cay', 'Spice level', 1, 0, 1);
SET @g7 = SCOPE_IDENTITY();
INSERT INTO dbo.option_choices (option_group_id, name, nameEn, extraPrice, isDefault) VALUES
(@g7, N'Cay vừa', 'Medium spicy', 0, 1),
(@g7, N'Cay nhiều', 'Extra spicy', 0, 0),
(@g7, N'Siêu cay', 'Super spicy', 5000, 0);

INSERT INTO dbo.option_groups (menu_item_id, name, nameEn, required, multiSelect, displayOrder) VALUES
(@item3, N'Món thêm', 'Add-ons', 0, 1, 2);
SET @g8 = SCOPE_IDENTITY();
INSERT INTO dbo.option_choices (option_group_id, name, nameEn, extraPrice, isDefault) VALUES
(@g8, N'Thêm phô mai', 'Extra cheese', 8000, 0),
(@g8, N'Khoai tây chiên', 'French fries', 15000, 0);

-- ----- Cánh Gà Sốt Cay -----
DECLARE @item4 INT = (SELECT id FROM dbo.menu_items WHERE name = N'Cánh Gà Sốt Cay');
DECLARE @g9 INT, @g10 INT;

INSERT INTO dbo.option_groups (menu_item_id, name, nameEn, required, multiSelect, displayOrder) VALUES
(@item4, N'Độ cay', 'Spice level', 1, 0, 1);
SET @g9 = SCOPE_IDENTITY();
INSERT INTO dbo.option_choices (option_group_id, name, nameEn, extraPrice, isDefault) VALUES
(@g9, N'Cay vừa', 'Medium spicy', 0, 1),
(@g9, N'Cay nhiều', 'Extra spicy', 0, 0),
(@g9, N'Siêu cay', 'Super spicy', 5000, 0);

INSERT INTO dbo.option_groups (menu_item_id, name, nameEn, required, multiSelect, displayOrder) VALUES
(@item4, N'Món thêm', 'Add-ons', 0, 1, 2);
SET @g10 = SCOPE_IDENTITY();
INSERT INTO dbo.option_choices (option_group_id, name, nameEn, extraPrice, isDefault) VALUES
(@g10, N'Thêm phô mai', 'Extra cheese', 8000, 0),
(@g10, N'Khoai tây chiên', 'French fries', 15000, 0);

-- ----- Mỳ Ý Sốt Bò Bằm -----
DECLARE @item5 INT = (SELECT id FROM dbo.menu_items WHERE name = N'Mỳ Ý Sốt Bò Bằm');
DECLARE @g11 INT, @g12 INT;

INSERT INTO dbo.option_groups (menu_item_id, name, nameEn, required, multiSelect, displayOrder) VALUES
(@item5, N'Kích cỡ', 'Portion size', 1, 0, 1);
SET @g11 = SCOPE_IDENTITY();
INSERT INTO dbo.option_choices (option_group_id, name, nameEn, extraPrice, isDefault) VALUES
(@g11, N'Phần thường', 'Regular', 0, 1),
(@g11, N'Phần lớn', 'Large', 12000, 0);

INSERT INTO dbo.option_groups (menu_item_id, name, nameEn, required, multiSelect, displayOrder) VALUES
(@item5, N'Món thêm', 'Add-ons', 0, 1, 2);
SET @g12 = SCOPE_IDENTITY();
INSERT INTO dbo.option_choices (option_group_id, name, nameEn, extraPrice, isDefault) VALUES
(@g12, N'Phô mai bào thêm', 'Extra grated cheese', 7000, 0),
(@g12, N'Bánh mì bơ tỏi', 'Garlic bread', 12000, 0);

-- ----- Mỳ Ý Sốt Kem Nấm -----
DECLARE @item6 INT = (SELECT id FROM dbo.menu_items WHERE name = N'Mỳ Ý Sốt Kem Nấm');
DECLARE @g13 INT, @g14 INT;

INSERT INTO dbo.option_groups (menu_item_id, name, nameEn, required, multiSelect, displayOrder) VALUES
(@item6, N'Kích cỡ', 'Portion size', 1, 0, 1);
SET @g13 = SCOPE_IDENTITY();
INSERT INTO dbo.option_choices (option_group_id, name, nameEn, extraPrice, isDefault) VALUES
(@g13, N'Phần thường', 'Regular', 0, 1),
(@g13, N'Phần lớn', 'Large', 12000, 0);

INSERT INTO dbo.option_groups (menu_item_id, name, nameEn, required, multiSelect, displayOrder) VALUES
(@item6, N'Món thêm', 'Add-ons', 0, 1, 2);
SET @g14 = SCOPE_IDENTITY();
INSERT INTO dbo.option_choices (option_group_id, name, nameEn, extraPrice, isDefault) VALUES
(@g14, N'Phô mai bào thêm', 'Extra grated cheese', 7000, 0),
(@g14, N'Bánh mì bơ tỏi', 'Garlic bread', 12000, 0);

-- ----- Kem Ốc Quế Vani -----
DECLARE @item7 INT = (SELECT id FROM dbo.menu_items WHERE name = N'Kem Ốc Quế Vani');
DECLARE @g15 INT;

INSERT INTO dbo.option_groups (menu_item_id, name, nameEn, required, multiSelect, displayOrder) VALUES
(@item7, N'Topping', 'Topping', 0, 1, 1);
SET @g15 = SCOPE_IDENTITY();
INSERT INTO dbo.option_choices (option_group_id, name, nameEn, extraPrice, isDefault) VALUES
(@g15, N'Socola chip', 'Chocolate chips', 5000, 0),
(@g15, N'Hạt hạnh nhân', 'Almonds', 6000, 0);

-- ----- Bánh Trứng Nướng -----
DECLARE @item8 INT = (SELECT id FROM dbo.menu_items WHERE name = N'Bánh Trứng Nướng');
DECLARE @g16 INT;

INSERT INTO dbo.option_groups (menu_item_id, name, nameEn, required, multiSelect, displayOrder) VALUES
(@item8, N'Topping', 'Topping', 0, 1, 1);
SET @g16 = SCOPE_IDENTITY();
INSERT INTO dbo.option_choices (option_group_id, name, nameEn, extraPrice, isDefault) VALUES
(@g16, N'Socola chip', 'Chocolate chips', 5000, 0),
(@g16, N'Hạt hạnh nhân', 'Almonds', 6000, 0);
GO

-- ============================================================================
-- DỮ LIỆU MẪU: promotions (4 chương trình khuyến mãi)
-- ============================================================================
INSERT INTO dbo.promotions (badgeText, label, labelEn, title, titleEn, description, descriptionEn, priceNew, priceOld, iconClass, iconBgClass, buttonText, buttonTextEn, buttonLink) VALUES
('-50%', N'COMBO TIẾT KIỆM', 'SAVER COMBO', N'Combo Gà Giòn 2 Miếng', '2-Piece Crispy Chicken Combo',
 N'Bao gồm 2 miếng gà giòn, 1 cơm, 1 nước ngọt size vừa.', 'Includes 2 pieces of crispy chicken, 1 rice, 1 medium soft drink.',
 N'59.000đ', N'118.000đ', 'fa-solid fa-bucket', 'combo-icon', N'Đặt ngay', 'Order now', 'menu'),
(N'MUA 1 TẶNG 1', N'ƯU ĐÃI THỨ 4', 'WEDNESDAY DEAL', N'Gà Sốt Cay Mua 1 Tặng 1', 'Spicy Chicken Buy 1 Get 1',
 N'Áp dụng cho đơn đặt qua ứng dụng, thứ 4 hàng tuần.', 'Applies to app orders every Wednesday.',
 N'39.000đ', N'78.000đ', 'fa-solid fa-pepper-hot', 'spicy-icon', N'Đặt ngay', 'Order now', 'menu'),
(N'SINH VIÊN', N'ƯU ĐÃI HỌC SINH SV', 'STUDENT DEAL', N'Giảm 20% Toàn Thực Đơn', '20% Off Whole Menu',
 N'Chỉ cần xuất trình thẻ học sinh, sinh viên khi thanh toán.', 'Just show your student ID at checkout.',
 N'Giảm 20%', NULL, 'fa-solid fa-graduation-cap', 'student-icon', N'Xem chi tiết', 'View details', 'menu'),
('FREESHIP', N'GIAO HÀNG TẬN NƠI', 'FREE DELIVERY', N'Miễn Phí Giao Hàng', 'Free Shipping',
 N'Cho đơn hàng từ 99.000đ trong bán kính 3km.', 'For orders from 99,000đ within a 3km radius.',
 N'0đ Ship', NULL, 'fa-solid fa-motorcycle', 'ship-icon', N'Đặt ngay', 'Order now', 'menu');
GO

-- ============================================================================
-- DỮ LIỆU MẪU: services (6 dịch vụ)
-- ============================================================================
INSERT INTO dbo.services (iconClass, title, titleEn, description, descriptionEn, linkText, linkTextEn, link) VALUES
('fa-solid fa-motorcycle', N'Giao Hàng Tận Nơi', 'Home Delivery',
 N'Đặt món yêu thích và nhận hàng ngay tại nhà chỉ trong 30 phút.', 'Order your favorite food and get it delivered home in 30 minutes.',
 N'Đặt giao hàng', 'Order delivery', 'service?type=delivery'),
('fa-solid fa-bag-shopping', N'Đặt Đến Lấy', 'Pickup Order',
 N'Đặt trước trên app, ghé cửa hàng lấy ngay, không cần chờ đợi.', 'Pre-order on the app, then pick it up in-store with no waiting.',
 N'Đặt đến lấy', 'Order pickup', 'service?type=pickup'),
('fa-solid fa-champagne-glasses', N'Tổ Chức Tiệc & Sự Kiện', 'Parties & Events',
 N'Không gian ấm cúng, phù hợp tổ chức sinh nhật, tiệc nhóm bạn bè.', 'A cozy space perfect for birthdays and get-togethers with friends.',
 N'Liên hệ đặt tiệc', 'Contact us', 'service?type=party'),
('fa-solid fa-building', N'Đặt Suất Ăn Doanh Nghiệp', 'Corporate Catering',
 N'Giải pháp suất ăn số lượng lớn cho công ty, hội nghị, sự kiện.', 'Bulk meal solutions for companies, conferences and events.',
 N'Nhận báo giá', 'Get a quote', 'service?type=corporate'),
('fa-solid fa-mobile-screen-button', N'Đặt Hàng Qua App', 'Order via App',
 N'Tải ứng dụng Jolliebear để tích điểm và nhận ưu đãi độc quyền.', 'Download the Jolliebear app to earn points and exclusive deals.',
 N'Tải ứng dụng', 'Download app', 'service?type=app'),
('fa-solid fa-headset', N'Hỗ Trợ Khách Hàng 24/7', '24/7 Customer Support',
 N'Đội ngũ CSKH luôn sẵn sàng giải đáp mọi thắc mắc của bạn.', 'Our support team is always ready to answer your questions.',
 N'Liên hệ hotline', 'Call hotline', 'service?type=support');
GO

-- ============================================================================
-- DỮ LIỆU MẪU: orders + order_items + order_item_options
-- (2 đơn hàng demo gắn với tài khoản demo@jolliebear.vn, để tính năng "Lịch sử
--  đơn hàng" (/orders) và "Xác nhận đơn hàng" (/order-confirmation) có dữ liệu
--  hiển thị ngay mà không cần đặt hàng thử trước)
-- ============================================================================
DECLARE @demoUser INT = (SELECT id FROM dbo.users WHERE email = 'demo@jolliebear.vn');
DECLARE @orderChickenId INT = (SELECT id FROM dbo.menu_items WHERE name = N'Gà Giòn Truyền Thống');
DECLARE @orderSpicyId INT = (SELECT id FROM dbo.menu_items WHERE name = N'Gà Sốt Cay Hàn Quốc');
DECLARE @orderDessertId INT = (SELECT id FROM dbo.menu_items WHERE name = N'Kem Ốc Quế Vani');

-- Đơn hàng 1: đã hoàn thành (giao hàng)
DECLARE @order1 INT;
INSERT INTO dbo.orders (orderCode, user_id, orderType, status, deliveryAddress, contactPhone, note, subtotal, shippingFee, total, createdAt) VALUES
('JB1000000001', @demoUser, 'DELIVERY', 'COMPLETED', N'123 Đường Nguyễn Huệ, Quận 1, TP.HCM', '0901234567', N'Giao ngoài giờ hành chính giúp',
 93000, 15000, 108000, DATEADD(DAY, -3, SYSDATETIME()));
SET @order1 = SCOPE_IDENTITY();

DECLARE @oi1 INT;
INSERT INTO dbo.order_items (order_id, menu_item_id, itemName, unitPrice, quantity, lineTotal, note) VALUES
(@order1, @orderChickenId, N'Gà Giòn Truyền Thống', 35000, 1, 65000, NULL);
SET @oi1 = SCOPE_IDENTITY();
INSERT INTO dbo.order_item_options (order_item_id, groupName, choiceName, extraPrice) VALUES
(@oi1, N'Chọn số lượng', N'2 Miếng', 30000),
(@oi1, N'Độ cay', N'Cay vừa', 0);

DECLARE @oi2 INT;
INSERT INTO dbo.order_items (order_id, menu_item_id, itemName, unitPrice, quantity, lineTotal, note) VALUES
(@order1, @orderDessertId, N'Kem Ốc Quế Vani', 15000, 1, 20000, NULL);
SET @oi2 = SCOPE_IDENTITY();
INSERT INTO dbo.order_item_options (order_item_id, groupName, choiceName, extraPrice) VALUES
(@oi2, N'Topping', N'Socola chip', 5000);

-- Đơn hàng 2: đang chờ xác nhận (mới đặt)
DECLARE @order2 INT;
INSERT INTO dbo.orders (orderCode, user_id, orderType, status, deliveryAddress, contactPhone, note, subtotal, shippingFee, total, createdAt) VALUES
('JB1000000002', @demoUser, 'PICKUP', 'PENDING', NULL, '0901234567', N'Lấy hàng trước 12h trưa',
 42000, 0, 42000, SYSDATETIME());
SET @order2 = SCOPE_IDENTITY();

DECLARE @oi3 INT;
INSERT INTO dbo.order_items (order_id, menu_item_id, itemName, unitPrice, quantity, lineTotal, note) VALUES
(@order2, @orderSpicyId, N'Gà Sốt Cay Hàn Quốc', 42000, 1, 42000, NULL);
SET @oi3 = SCOPE_IDENTITY();
INSERT INTO dbo.order_item_options (order_item_id, groupName, choiceName, extraPrice) VALUES
(@oi3, N'Độ cay', N'Cay vừa', 0);
GO

PRINT N'Đã tạo xong database JollieBearDB đầy đủ (users, menu, options, promotions, services, orders).';
GO
